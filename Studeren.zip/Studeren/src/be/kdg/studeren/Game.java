package be.kdg.studeren;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Game extends IngevenVraagEnAntwoord {
    public static void main(String[] args) {
        //scanner
        Scanner scanner = new Scanner(System.in);

        //Begin spel

        Menu menu = new Menu();
        IngevenVraagEnAntwoord output = new IngevenVraagEnAntwoord();

        System.out.printf("Geef je naam: ");
        String name = scanner.next();
        Player player = new Player(name);
        // System.out.println("Hello " + player.getNaam());

        boolean geldigAntwoordEersteMenu = false;
        boolean geldigAntwoordTweedeMenu = false;
        boolean geldigAntwoordDerdeMenu = false;

        try {

            //eerste menu
            while (!geldigAntwoordEersteMenu) {

                System.out.println(menu.Menu1());
                int antwoordPlayerEersteMenu = 0;
                int antwoordPlayerTweedeMenu = 0;
                antwoordPlayerEersteMenu = scanner.nextInt();

                //eerste menu
                switch (antwoordPlayerEersteMenu) {
                    case 1:
                        geldigAntwoordEersteMenu = true;
                        while (!geldigAntwoordTweedeMenu) {
                            System.out.println(menu.Menu2());
                            antwoordPlayerTweedeMenu = scanner.nextInt();

                            // tweede menu
                            switch(antwoordPlayerTweedeMenu) {
                                case 1:
                                    geldigAntwoordTweedeMenu = true;

                                    // gegevens invullen bij het vak frans
                                    output.setVraag();
                                    output.setAntwoord();
                                    output.aanmakenBestand();
                                    output.toevoegenRecords();
                                    output.sluitbestand();

                                    break;
                                case 2:
                                    geldigAntwoordTweedeMenu = true;

                                    // gegevens invullen bij het vak programmeren

                                    break;
                                case 3:
                                    geldigAntwoordTweedeMenu = true;
                                    System.out.println(menu.Menu1());
                                    geldigAntwoordEersteMenu = false;
                                    geldigAntwoordTweedeMenu = false;
                                    antwoordPlayerTweedeMenu = scanner.nextInt();
                                    break;
                            }

                        }
                        break;
                    case 2:
                        geldigAntwoordEersteMenu = true;
                            System.out.println(menu.Menu3());
                            while(!geldigAntwoordDerdeMenu) {
                                int antwoordPlayerDerdeMenu = scanner.nextInt();

                                //nog een switch voor input

                            }

                        break;
                }
            }
        } catch (InputMismatchException ime) {
            System.out.println("Vul een geldig antwoord in");
            //ime.printStackTrace();
        }
    }
}
