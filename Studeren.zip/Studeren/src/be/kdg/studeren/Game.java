package be.kdg.studeren;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Game {
    public static void main(String[] args) {
        //scanner
        Scanner scanner = new Scanner(System.in);

        //Begin spel

        System.out.printf("Geef je naam: ");
        String name = scanner.next();
        Player player = new Player(name);
        // System.out.println("Hello " + player.getNaam());

        //eerste keuzemenu TODO: formatting
        boolean geldigAntwoordEersteMenu = false;

            while (!geldigAntwoordEersteMenu) {
                System.out.println("Wens je");
                System.out.println("1.Gegevens invoeren");
                System.out.println("2.Test afnemen");

                int antwoordPlayerEersteMenu = 0;
                try {
                    antwoordPlayerEersteMenu = scanner.nextInt();

                    if (antwoordPlayerEersteMenu == 1) {
                        geldigAntwoordEersteMenu = true;
                        System.out.println("Voor welk vak wens je gegevens in te geven?");
                        System.out.println("1.Frans");
                        System.out.println("2.Programmeren");
                        System.out.println("3.Terug naar vorig menu");
                        int antwoordPlayerTweedeMenu = scanner.nextInt();

                        if(antwoordPlayerTweedeMenu==1){

                        }
                        else if(antwoordPlayerTweedeMenu==2){

                        }
                        else if (antwoordPlayerTweedeMenu==3){

                        }
                        else {
                            System.out.println("Welk vak?");
                            System.out.println("1.Statistiek");
                            System.out.println("1.Statistiek");
                        }

                    } else if (antwoordPlayerEersteMenu == 2) {
                        geldigAntwoordEersteMenu = true;
                        int antwoordPlayerDerdeMenu = scanner.nextInt();

                    } else {
                        System.out.println("Geef een geldig antwoordPlayerEersteMenu");
                    }
                } catch (InputMismatchException ime) {
                    System.out.println("NIET GOED HE");
                    scanner.reset();
                    //ime.printStackTrace();
                }
            }

    }
}
