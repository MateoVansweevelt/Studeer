package be.kdg.studeren;

public class Menu {

    public String Menu1() {
        return String.format("Wens je %n 1.Gegevens invoeren %n 2.Test afnemen %n");
    }

    public String Menu2() {
        return String.format("Voor welk vak wens je gegevens in te geven? %n 1.Frans %n 2.Programmeren %n 3.Terug naar vorig menu %n");
    }

    public String Menu3() {
        return String.format("Welk vak? %n 1.Statistiek %n");
    }

    public String Menu4() {
        return String.format("Welk vak? %n 1.Statistiek%n");
    }

}
