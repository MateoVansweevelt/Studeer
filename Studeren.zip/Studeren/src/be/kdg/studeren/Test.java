package be.kdg.studeren;

import java.util.List;

public class Test extends Categorien {
    private int aantalVragen;
    private int aantalVakken;
    private int score;

    private List<Categorien> categorien;

    public Test(int aantalVragen, int aantalVakken) {
        this.aantalVragen = aantalVragen;
        this.aantalVakken = aantalVakken;
    }

    //getters
    public int getAantalVragen() {
        return aantalVragen;
    }

    public int getAantalVakken() {
        return aantalVakken;
    }

    public int getScore() {
        return score;
    }

    //setters
    public void setAantalVragen(int aantalVragen) {
        this.aantalVragen = aantalVragen;
    }

    public void setAantalVakken(int aantalVakken) {
        this.aantalVakken = aantalVakken;
    }

    public void setScore(int score) {
        this.score = score;
    }
}
