package be.kdg.studeren.model;

import javafx.collections.ObservableList;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.List;
import java.util.Scanner;

public class Game {
    private List<Vraag> vragenFrans = new ArrayList<Vraag>();
    private List<Vraag> vragenProgrammeren = new ArrayList<>();
    private List<Vraag> vragenStatistiek = new ArrayList<>();

    private String naam;

    //moet enum worden
    //private String watIngeven;


    public void addVraagFrans(Vraag vraag) {
        vragenFrans.add(vraag);
        System.out.println("VRAAG TOEGEVOEGD");
        saveFrans();
    }

    public void saveFrans() {
        System.out.println("SAVING...");
        int vraagIdFrans = vragenFrans.size();
        try(Formatter fm = new Formatter("vragen.txt")) {
            for(Vraag vraag: vragenFrans) {
                fm.format("%d,%s,%s\n", vraagIdFrans, vraag.getVraag(), vraag.getAntwoord());
            }
        } catch (IOException ioe) {
            System.out.println("Er is een probleem opgetreden bij het saven.");
        }
    }

    public void loadFrans() {
        System.out.println("Loading...");

        //EERST TESTEN OF FILE BESTAAT
        Path pathToFile = Paths.get("vragen.txt");

        if (Files.exists(pathToFile)) {
            try(Scanner s = new Scanner(new File("vragen.txt"))) {
                while (s.hasNext()) {
                    String oneLine = s.nextLine();
                    String[] strings = oneLine.split(",");

                    //print de ingeladen vragen in de console
                    System.out.println("id: " + strings[0] + " Vraag: " + strings[1] + " antwoord: " + strings[2]);
                }
            } catch (IOException ioe) {
                System.out.println("Er is een probleem opgetreden bij het laden.");
            }
        }
    }

    //getters
    public List<Vraag> getVragenFrans() {
        return vragenFrans;
    }

    public List<Vraag> getVragenProgrammeren() {
        return vragenProgrammeren;
    }

    public List<Vraag> getVragenStatistiek() {
        return vragenStatistiek;
    }

    public String getNaam() {
        return naam;
    }

    //setters
    public void setNaam(String naam) {
        this.naam = naam;
    }

/*    public void setWatIngeven(String watIngeven) {
        this.watIngeven = watIngeven;
    }*/


}
