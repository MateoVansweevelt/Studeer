package be.kdg.studeren.model;

import java.io.IOException;
import java.util.Formatter;

public class Vraag {

    private String vraag;
    private String antwoord;

    public Vraag(String vraag, String antwoord) {
        this.vraag = vraag;
        this.antwoord = antwoord;
    }


    public String getVraag() {
        return vraag;
    }

    public String getAntwoord() {
        return antwoord;
    }
}
