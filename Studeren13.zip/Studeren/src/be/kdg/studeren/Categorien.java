package be.kdg.studeren;

public class Categorien {
    private String categorie;
    private String vraag;
    private String antwoord;
    private int vraagNummer;
    private boolean gegenereerd;

    //vraag en antwoord kan leeg zijn?
    public Categorien(String categorie, int vraagNummer) {
        this(categorie,"","");
    }

    public Categorien(String categorie, String vraag, String antwoord) {
        this.categorie = categorie;
        this.vraag = vraag;
        this.antwoord = antwoord;
        this.vraagNummer = vraagNummer;
    }

    //default constructor
    public Categorien() {
        this("","","");
    }

    enum Categorie {
        STATISTIEK, FRANS, PROGRAMMEREN
    }

    //getters
    public String getCategorie() {
        return categorie;
    }

    public String getVraag() {
        return vraag;
    }

    public String getAntwoord() {
        return antwoord;
    }

    public int getVraagNummer() {
        return vraagNummer;
    }

    public boolean isGegenereerd() {
        return gegenereerd;
    }

    //setters

    public void setCategorie(String categorie) {
        this.categorie = categorie;
    }

    public void setVraag(String vraag) {
        this.vraag = vraag;
    }

    public void setAntwoord(String antwoord) {
        this.antwoord = antwoord;
    }

    public void setVraagNummer(int vraagNummer) {
        this.vraagNummer = vraagNummer;
    }

    public void setGegenereerd(boolean gegenereerd) {
        this.gegenereerd = gegenereerd;
    }
}
