package be.kdg.studeren;

public class Player {
    private String naam;

    public Player(String naam) {
        this.naam = naam;
    }

    //setters
    public void setNaam(String naam) {
        this.naam = naam;
    }

    //getters
    public String getNaam() {
        return naam;
    }
}
