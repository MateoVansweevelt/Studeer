package be.kdg.studeren.model;

import java.util.Scanner;

public class VraagManager {
    private int vraagId;
    private String Vraag;
    private String antwoord;
    private Scanner scanner = new Scanner(System.in);

    public VraagManager(int vraagId, String vraag, String antwoord) {
        this.vraagId = vraagId;
        Vraag = vraag;
        this.antwoord = antwoord;
    }

    public void setVraagId(int vraagId) {
        this.vraagId = vraagId;
    }

    public void setVraag(String vraag) {
        System.out.println("Vraag: ");
        vraag = scanner.nextLine();
    }

    public void setAntwoord(String antwoord) {
        System.out.println("Antwoord: ");
        antwoord = scanner.nextLine();
    }

    public void IdUitdelen() {

    }
}
