package be.kdg.studeren.view.afnemenTest;

import be.kdg.studeren.model.Game;

public class AfnemenTestPresenter {
        private Game model;
        private AfnemenTestView view;

        public AfnemenTestPresenter(Game model, AfnemenTestView view) {
            this.model = model;
            this.view = view;
            addEventHandlers();
            updateView();
        }

        private void addEventHandlers() {
        }

        private void updateView() {

        }
    }
