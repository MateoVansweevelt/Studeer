package be.kdg.studeren.view.afnemenTest;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class AfnemenTestView extends BorderPane {
    private Label lblTestAfnemen;
    private Label lblVraag;
    private TextArea taAntwoordVlak;
    private Button btnControleer;
    private Button btnPause;
    private Button btnTerug;

    public AfnemenTestView() {
        initialisatieNodes();
        layoutNodes();
    }

    private void initialisatieNodes() {
        lblTestAfnemen = new Label("Test Afnemen");
        lblVraag = new Label();
        taAntwoordVlak = new TextArea();
        btnPause = new Button("Pauze");
        btnControleer = new Button("Controleer");
        btnTerug = new Button("Terug");
    }

    private void layoutNodes() {
        this.setTop(lblTestAfnemen);
        this.setTop(btnPause);
        VBox vBox = new VBox();
        vBox.getChildren().addAll(lblVraag, taAntwoordVlak);
        taAntwoordVlak.setId("antwoord");
        this.setCenter(vBox);
        this.setBottom(btnTerug);
        this.setBottom(btnControleer);
    }

    public Label getLblVraag() {
        return lblVraag;
    }
}
