package be.kdg.studeren.view.afnemenTest;

import be.kdg.studeren.model.Game;
import be.kdg.studeren.view.homeScreen.HomeScreenPresenter;
import be.kdg.studeren.view.homeScreen.HomeScreenView;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

public class AfnemenTestPresenter {
    private Game model;
    private AfnemenTestView view;

    public AfnemenTestPresenter(Game model, AfnemenTestView view) {
        this.model = model;
        this.view = view;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        view.getBtnTerug().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                HomeScreenView homeScreenView = new HomeScreenView();
                HomeScreenPresenter homeScreenPresenter = new HomeScreenPresenter(model, homeScreenView);
                view.getScene().setRoot(homeScreenView);
            }
        });
        view.getBtnControleer().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                model.setAntwoordUser(view.getTaAntwoordVlak().getText());
                if (model.controleerAntwoord()) {
                    System.out.println("true");
                    view.getTaAntwoordVlak().setStyle("-fx-background-color: green");
                    view.getTaAntwoordVlak().setText("");
                    updateView();
                } else {
                    System.out.println("false");
                    view.getTaAntwoordVlak().setStyle("-fx-background-color: red");
                    view.getTaAntwoordVlak().setText("");
                    updateView();
                }
            }
        });
    }

    private void updateView() {
        view.getLblVraag().setText("Vraag: " + model.vraagKiezen());
    }
}