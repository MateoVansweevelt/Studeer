package be.kdg.studeren.view.gegevensInvoeren;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class GegevensInvoerenView extends BorderPane {

    Label lblGegevensInvoeren;
    Button btnFrans;
    Button btnProgrammeren;
    Button btnTerug;

    public GegevensInvoerenView() {
        initializeNodes();
        layoutNodes();
    }

    private void layoutNodes() {
        this.setTop(lblGegevensInvoeren);
        lblGegevensInvoeren.setId("topLeft");
        VBox vbox = new VBox();
        vbox.setSpacing(10);
        vbox.getChildren().addAll(btnFrans, btnProgrammeren);
        vbox.setAlignment(Pos.CENTER);
        btnFrans.setId("customButton");
        btnProgrammeren.setId("customButton");
        this.setCenter(vbox);
        this.setBottom(btnTerug);
        this.setStyle("-fx-alignment: left");
        this.setStyle("-fx-padding: 20px");
    }

    private void initializeNodes() {
        lblGegevensInvoeren = new Label("Gegevens Invoeren");
        btnFrans = new Button("Frans");
        btnProgrammeren = new Button("Programmeren");
        btnTerug = new Button("Terug");
    }
}
