package be.kdg.studeren.view.homeScreen;

import be.kdg.studeren.model.Game;
import be.kdg.studeren.view.afnemenTest.AfnemenTestPresenter;
import be.kdg.studeren.view.afnemenTest.AfnemenTestView;
import be.kdg.studeren.view.gegevensInvoeren.GegevensInvoerenPresenter;
import be.kdg.studeren.view.gegevensInvoeren.GegevensInvoerenView;
import be.kdg.studeren.view.testKiezen.TestKiezenPresenter;
import be.kdg.studeren.view.testKiezen.TestKiezenView;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

public class HomeScreenPresenter {

    private Game model;
    private HomeScreenView view;

    public HomeScreenPresenter(Game model, HomeScreenView view) {
        this.model = model;
        this.view = view;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        view.getBtnAfsluiten().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                System.exit(0);
            }
        });
        view.getBtnTestAfnemen().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                TestKiezenView testKiezenView = new TestKiezenView();
                TestKiezenPresenter testKiezenPresenter = new TestKiezenPresenter(model, testKiezenView);
                view.getScene().setRoot(testKiezenView);
            }
        });
        view.getBtnGegevensInvoeren().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                GegevensInvoerenView gegevensInvoerenView = new GegevensInvoerenView();
                GegevensInvoerenPresenter gegevensInvoerenPresenter = new GegevensInvoerenPresenter(model, gegevensInvoerenView);
                view.getScene().setRoot(gegevensInvoerenView);
            }
        });
        view.lblNaam.setText(model.getNaam());
    }


    private void updateView() {

    }

}
