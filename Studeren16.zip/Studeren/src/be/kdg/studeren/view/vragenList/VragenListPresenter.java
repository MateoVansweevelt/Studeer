package be.kdg.studeren.view.vragenList;

import be.kdg.studeren.model.Game;
import be.kdg.studeren.model.SoortVraag;
import be.kdg.studeren.view.gegevensInvoeren.GegevensInvoerenPresenter;
import be.kdg.studeren.view.gegevensInvoeren.GegevensInvoerenView;
import be.kdg.studeren.view.toevoegenVraag.ToevoegenVraagPresenter;
import be.kdg.studeren.view.toevoegenVraag.ToevoegenVraagView;
import be.kdg.studeren.view.vraagScreen.VraagPresenter;
import be.kdg.studeren.view.vraagScreen.VraagView;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

public class VragenListPresenter {
    private Game model;
    private VragenListView view;

    public VragenListPresenter(Game model, VragenListView view) {
        this.model = model;
        this.view = view;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
                view.getLvAlleenVragenlijst().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {

                //om vraag en antwoord te setten
                //eerst testen of de rij die geselecteerd is niet leeg is
                if(!view.getLvAlleenVragenlijst().getSelectionModel().isEmpty()) {

                    //model.setVraagEdit(view.lvAlleenVragenlijst.getSelectionModel().getSelectedItem().toString());
                    model.setIndex(view.getLvAlleenVragenlijst().getSelectionModel().getSelectedIndex());
                    VraagView viewVraag = new VraagView();
                    VraagPresenter vraagPresenter = new VraagPresenter(model, viewVraag);
                    view.getScene().setRoot(viewVraag);

                }
                else {
                    System.out.println("LEGE RIJ GESELECTEERD");
                }
            }
        });

        view.getBtnTerug().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                GegevensInvoerenView viewGegevensInvoeren = new GegevensInvoerenView();
                GegevensInvoerenPresenter gegevensInvoerenPresenter = new GegevensInvoerenPresenter(model, viewGegevensInvoeren);
                view.getScene().setRoot(viewGegevensInvoeren);
                //model.setLijstFransAlGeladen(false);
               // model.setLijstProgrammerenAlGeladen(false);
            }
        });

        view.btnToevoegen.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                ToevoegenVraagView viewToevoegenVraag = new ToevoegenVraagView();
                ToevoegenVraagPresenter vraagPresenter = new ToevoegenVraagPresenter(model, viewToevoegenVraag);
                view.getScene().setRoot(viewToevoegenVraag);
            }
        });

/*        view.btnClear.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                view.lvAlleenVragenlijst.getItems().clear();
            }
        });

        view.btnSet.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                model.loadFransListview();
            }
        });*/

        System.out.println("SOORTVRAAG: " + model.getTypeVraag());

        view.lvAlleenVragenlijst.getItems().clear();

        //laad de lijst in de listview
        //view.lvVragenlijst.setItems(model.getListFrans());
        if(model.getTypeVraag() == (SoortVraag.FRANS)) {
            view.lvAlleenVragenlijst.setItems(model.getAlleenVragenFrans());

            //laad de vragen van de file in een ObservableList
            if(!model.isLijstFransAlGeladen()) {
                //mag maar 1 keer uitgevoerd worden
                model.loadFransListview();
                model.setLijstFransAlGeladen(true);
            }

            //model.UpdateListviewFrans();
        }

        else if(model.getTypeVraag() == (SoortVraag.PROGRAMMEREN)) {
            view.lvAlleenVragenlijst.setItems(model.getAlleenVragenProgrammeren());

            //laad de vragen van de file in een ObservableList
            if(!model.isLijstProgrammerenAlGeladen()) {
                //mag maar 1 keer uitgevoerd worden
                model.loadProgrammerenListview();
                model.setLijstProgrammerenAlGeladen(true);
            }

            //model.UpdateListViewProgrammeren();
        }

    }

    private void updateView() {

    }
}
