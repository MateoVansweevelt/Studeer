package be.kdg.studeren.model;

import java.util.Random;

public class Statistiek {
    private final int MIN = 1;
    private final int MAX = 100;

    boolean isAntwoordJuist;

    private int antwoordPlayer;
    Random r = new Random();

    public Statistiek() {

    }

    public void Gemiddelde() {

        int getal1 = r.nextInt((MAX - MIN) + 1) + MIN;
        int getal2 = r.nextInt((MAX - MIN) + 1) + MIN;
        int getal3 = r.nextInt((MAX - MIN) + 1) + MIN;

        if((getal1 + getal2 + getal3) / 3 == antwoordPlayer) {
            isAntwoordJuist = true;
            //model.setScore()?
        }
        else {
            isAntwoordJuist = false;
        }

    }

    public void StandaardDeviatie() {
        int getal1 = r.nextInt((MAX - MIN) + 1) + MIN;
        int getal2 = r.nextInt((MAX - MIN) + 1) + MIN;
        int getal3 = r.nextInt((MAX - MIN) + 1) + MIN;
        int getal4 = r.nextInt((MAX - MIN) + 1) + MIN;
        int getal5 = r.nextInt((MAX - MIN) + 1) + MIN;
        double gemiddelde = (getal1 + getal2 + getal3 + getal4 + getal5) / 3;

        double afstandGetal1 = getal1 - gemiddelde;
        double afstandGetal2 = getal2 - gemiddelde;
        double afstandGetal3 = getal3 - gemiddelde;
        double afstandGetal4 = getal4 - gemiddelde;
        double afstandGetal5 = getal5 - gemiddelde;

        double kwadraatAfstandGetal1 = afstandGetal1 * afstandGetal1;
        double kwadraatAfstandGetal2 = afstandGetal2 * afstandGetal2;
        double kwadraatAfstandGetal3 = afstandGetal3 * afstandGetal3;
        double kwadraatAfstandGetal4 = afstandGetal4 * afstandGetal4;
        double kwadraatAfstandGetal5 = afstandGetal5 * afstandGetal5;

        //nog niet af

    }

    public void HoogsteWaarde() {
        int getal1 = r.nextInt((MAX - MIN) + 1) + MIN;
        int getal2 = r.nextInt((MAX - MIN) + 1) + MIN;
        int getal3 = r.nextInt((MAX - MIN) + 1) + MIN;

        int max =  Math.max(Math.max(getal1,getal2),getal3);

        if(antwoordPlayer == max) {
            isAntwoordJuist = true;
        }
        else
        {
            isAntwoordJuist = false;
        }

    }

    public int getAntwoordPlayer() {
        return antwoordPlayer;
    }

    public void setAntwoordPlayer(int antwoordPlayer) {
        this.antwoordPlayer = antwoordPlayer;
    }
}
