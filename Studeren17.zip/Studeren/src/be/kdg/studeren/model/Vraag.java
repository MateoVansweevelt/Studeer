package be.kdg.studeren.model;

public class Vraag {

    private String vraag;
    private String antwoord;

    public Vraag(String vraag, String antwoord) {
        this.vraag = vraag;
        this.antwoord = antwoord;
    }

    public String getVraag() {
        return vraag;
    }

    public String getAntwoord() {
        return antwoord;
    }

    @Override
    public String toString() {
        return String.format("%s,%s\n", getVraag(), getAntwoord());
    }
}
