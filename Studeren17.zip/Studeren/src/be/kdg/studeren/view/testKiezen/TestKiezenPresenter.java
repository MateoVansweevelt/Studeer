package be.kdg.studeren.view.testKiezen;

import be.kdg.studeren.model.Game;
import be.kdg.studeren.model.SoortVraag;
import be.kdg.studeren.view.afnemenTest.AfnemenTestPresenter;
import be.kdg.studeren.view.afnemenTest.AfnemenTestView;
import be.kdg.studeren.view.homeScreen.HomeScreenPresenter;
import be.kdg.studeren.view.homeScreen.HomeScreenView;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

public class TestKiezenPresenter {
    private Game model;
    private TestKiezenView view;

    public TestKiezenPresenter(Game model, TestKiezenView view) {
        this.model = model;
        this.view = view;
        addEventhandlers();
        updateView();
    }

    private void addEventhandlers() {
        view.getBtnFrans().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                model.setTypeVraag(SoortVraag.FRANS);
                AfnemenTestView afnemenTestView = new AfnemenTestView();
                AfnemenTestPresenter afnemenTestPresenter = new AfnemenTestPresenter(model, afnemenTestView);
                view.getScene().setRoot(afnemenTestView);
            }
        });

        view.getBtnProgrammeren().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                model.setTypeVraag(SoortVraag.PROGRAMMEREN);
                AfnemenTestView afnemenTestView = new AfnemenTestView();
                AfnemenTestPresenter afnemenTestPresenter = new AfnemenTestPresenter(model, afnemenTestView);
                view.getScene().setRoot(afnemenTestView);
            }
        });

        view.getBtnTerug().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                HomeScreenView homeScreenView = new HomeScreenView();
                HomeScreenPresenter homeScreenPresenter = new HomeScreenPresenter(model ,homeScreenView);
                view.getScene().setRoot(homeScreenView);
            }
        });

    }

    private void updateView() {
        //hier niet nodig
    }
}
