package be.kdg.studeren.view.toevoegenVraag;

import be.kdg.studeren.model.Game;
import be.kdg.studeren.model.SoortVraag;
import be.kdg.studeren.model.Vraag;
import be.kdg.studeren.view.vraagScreen.VraagView;
import be.kdg.studeren.view.vragenList.VragenListPresenter;
import be.kdg.studeren.view.vragenList.VragenListView;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

public class ToevoegenVraagPresenter {
    private Game model;
    private ToevoegenVraagView view;

    public ToevoegenVraagPresenter(Game model, ToevoegenVraagView view) {
        this.model = model;
        this.view = view;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        view.getBtnTerug().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                VragenListView viewVragenList = new VragenListView();
                VragenListPresenter vragenListPresenter = new VragenListPresenter(model, viewVragenList);
                view.getScene().setRoot(viewVragenList);
            }
        });

        view.getBtnToevoegen().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                VragenListView viewVragenList = new VragenListView();
                VragenListPresenter vragenListPresenter = new VragenListPresenter(model, viewVragenList);
                view.getScene().setRoot(viewVragenList);

                if(model.getTypeVraag() == (SoortVraag.FRANS)) {
                    model.addVraagFrans(new Vraag(view.tfVraag.getText(),view.tfAntwoord.getText()));
                }
                else if(model.getTypeVraag() == (SoortVraag.PROGRAMMEREN)) {
                    model.addVraagProgrammeren(new Vraag(view.tfVraag.getText(),view.tfAntwoord.getText()));
                }

            }
        });
    }

    private void updateView() {
        //hier niet nodig
    }
}
