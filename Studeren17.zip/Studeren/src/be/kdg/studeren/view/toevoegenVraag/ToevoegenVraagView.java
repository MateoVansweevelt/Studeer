package be.kdg.studeren.view.toevoegenVraag;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class ToevoegenVraagView extends BorderPane {
    Label lblVraag;
    Label lblAntwoord;
    TextField tfVraag;
    TextField tfAntwoord;
    Button btnToevoegen;
    Button btnTerug;

    public ToevoegenVraagView() {
        initialisatieNodes();
        layoutNodes();
    }

    private void initialisatieNodes() {
        lblVraag = new Label("Vraag: ");
        lblAntwoord = new Label("Antwoord: ");
        tfVraag = new TextField();
        tfAntwoord = new TextField();
        btnToevoegen = new Button("Toevoegen");
        btnTerug = new Button("Terug");
    }

    private void layoutNodes() {

        HBox hBoxButtons = new HBox(btnToevoegen, btnTerug);
        VBox vboxVraagView = new VBox(lblVraag,tfVraag,lblAntwoord,tfAntwoord,hBoxButtons);

        super.setCenter(vboxVraagView);

        vboxVraagView.setPrefHeight(500);
        vboxVraagView.setPrefWidth(500);
        vboxVraagView.setPadding(new Insets(50,50,50,50));
        vboxVraagView.setSpacing(50);

        hBoxButtons.setPadding(new Insets(25,25,25,25));
        hBoxButtons.setSpacing(150);

    }

    Button getBtnToevoegen() {
        return btnToevoegen;
    }

    Button getBtnTerug() {
        return btnTerug;
    }
}
