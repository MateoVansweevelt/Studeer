package be.kdg.studeren.view.vraagScreen;

import be.kdg.studeren.model.Game;
import be.kdg.studeren.model.SoortVraag;
import be.kdg.studeren.model.Vraag;
import be.kdg.studeren.view.vragenList.VragenListPresenter;
import be.kdg.studeren.view.vragenList.VragenListView;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

public class VraagPresenter {
    private Game model;
    private VraagView view;

    public VraagPresenter(Game model, VraagView view) {
        this.model = model;
        this.view = view;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        view.getBtnTerug().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                VragenListView viewVragenList = new VragenListView();
                VragenListPresenter vragenListPresenter = new VragenListPresenter(model, viewVragenList);
                view.getScene().setRoot(viewVragenList);
            }
        });

        view.getBtnSave().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                if(model.getTypeVraag() == (SoortVraag.FRANS)) {
                    model.saveEditFrans(model.getIndex(),view.getTfVraag().getText(), view.getTfAntwoord().getText());
                    VragenListView viewVragenList = new VragenListView();
                    VragenListPresenter vragenListPresenter = new VragenListPresenter(model, viewVragenList);
                    view.getScene().setRoot(viewVragenList);
                }

                else if(model.getTypeVraag() == (SoortVraag.PROGRAMMEREN)) {
                    model.saveEditProgrammeren(model.getIndex(),view.getTfVraag().getText(), view.getTfAntwoord().getText());
                    VragenListView viewVragenList = new VragenListView();
                    VragenListPresenter vragenListPresenter = new VragenListPresenter(model, viewVragenList);
                    view.getScene().setRoot(viewVragenList);
                }

            }
        });

        view.btnVerwijderen.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                if(model.getTypeVraag() == (SoortVraag.FRANS)) {
                    model.removeVraagFrans(new Vraag(view.tfVraag.getText(),view.tfAntwoord.getText()));
                }
                else if(model.getTypeVraag() == (SoortVraag.PROGRAMMEREN)) {
                    model.removeVraagProgrammeren(new Vraag(view.tfVraag.getText(),view.tfAntwoord.getText()));
                }
                VragenListView viewVragenList = new VragenListView();
                VragenListPresenter vragenListPresenter = new VragenListPresenter(model, viewVragenList);
                view.getScene().setRoot(viewVragenList);
            }
        });

        view.tfVraag.setText(model.getVraagEdit());
        view.tfAntwoord.setText(model.getAntwoordEdit());
    }

    private void updateView() {
        //hier niet nodig
    }
}
