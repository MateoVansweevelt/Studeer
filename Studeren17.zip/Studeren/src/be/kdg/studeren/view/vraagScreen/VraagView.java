package be.kdg.studeren.view.vraagScreen;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class VraagView extends BorderPane {
    Label lblVraag;
    Label lblAntwoord;
    TextField tfVraag;
    TextField tfAntwoord;
    Button btnSave;
    Button btnTerug;
    Button btnVerwijderen;

    public VraagView() {
        initialisatieNodes();
        layoutNodes();
    }

    private void initialisatieNodes() {
        lblVraag = new Label("Vraag: ");
        lblAntwoord = new Label("Antwoord: ");
        tfVraag = new TextField();
        tfAntwoord = new TextField();
        btnSave = new Button("Save");
        btnTerug = new Button("Terug");
        btnVerwijderen = new Button("Verwijder");
    }

    private void layoutNodes() {

        HBox hBoxButtons = new HBox(btnSave,btnVerwijderen,btnTerug);
        VBox vboxVraagView = new VBox(lblVraag,tfVraag,lblAntwoord,tfAntwoord,hBoxButtons);

        super.setCenter(vboxVraagView);

        vboxVraagView.setPrefHeight(500);
        vboxVraagView.setPrefWidth(500);
        vboxVraagView.setPadding(new Insets(50,50,50,50));
        vboxVraagView.setSpacing(50);

        hBoxButtons.setPadding(new Insets(25,25,25,25));
        hBoxButtons.setSpacing(150);

    }

    TextField getTfVraag() {
        return tfVraag;
    }

    TextField getTfAntwoord() {
        return tfAntwoord;
    }

    Button getBtnSave() {
        return btnSave;
    }

    Button getBtnTerug() {
        return btnTerug;
    }

}

