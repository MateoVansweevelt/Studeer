package be.kdg.studeren.view.vragenList;

import be.kdg.studeren.model.Vraag;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

import java.util.List;

public class VragenListView extends BorderPane {

    //Frans
    ListView<String > lvAlleenVragenlijst;

    Button btnTerug;
    Button btnToevoegen;

    List<Vraag> list;

    public VragenListView() {
        initialisatieNodes();
        layoutNodes();
    }

    private void initialisatieNodes() {
        lvAlleenVragenlijst = new ListView<String>();
        btnTerug = new Button("Terug");
        btnToevoegen = new Button("Vraag Toevoegen");
    }

    private void layoutNodes() {
        VBox vboxVragenlijst = new VBox(lvAlleenVragenlijst,btnToevoegen,btnTerug);
        BorderPane.setAlignment(btnTerug, Pos.CENTER);

        super.setCenter(vboxVragenlijst);

        vboxVragenlijst.setPrefHeight(500);
        vboxVragenlijst.setPrefWidth(500);
        vboxVragenlijst.setPadding(new Insets(50,50,50,50));
        vboxVragenlijst.setSpacing(20);

    }

    ListView<String> getLvAlleenVragenlijst() {
        return lvAlleenVragenlijst;
    }

    Button getBtnTerug() {
        return btnTerug;
    }

    Button getBtnToevoegen() {
        return btnToevoegen;
    }
}
