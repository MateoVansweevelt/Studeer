package be.kdg.studeren;

import java.io.FileNotFoundException;
import java.util.Formatter;
import java.util.Scanner;

public class IngevenVraagEnAntwoord {
    private String vraag;
    private String antwoord;
    private int aantalVragen;
    private Scanner scanner = new Scanner(System.in);
    private Formatter formatter;

    public int getAantalVragen() {
        return aantalVragen;
    }

    public void setAantalVragen() {
        System.out.print("Geef het aantal vragen: ");
        aantalVragen = scanner.nextInt();
    }

    public void setVraag() {
        System.out.print("Geef de vraag in: ");
        vraag = scanner.next();
    }

    public void setAntwoord() {
        System.out.print("Geef het antwoord in: ");
        antwoord = scanner.next();
    }

    public void aanmakenBestand() {
        try {
            formatter = new Formatter("logVraagAntwoord.txt");
        } catch (FileNotFoundException fnfe) {
            System.out.println(fnfe.getCause().getMessage());
        }
    }

    public void toevoegenRecords() {
        for (int i = 1; i <= aantalVragen; i++) {
            formatter.format("%1d) vraag: %s antwoord: %s \n", i, vraag, antwoord);
        }
    }

    public void sluitbestand() {
        formatter.close();
    }
}

