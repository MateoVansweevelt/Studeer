package be.kdg.studeren;

import be.kdg.studeren.model.Game;
import be.kdg.studeren.view.afnemenTest.AfnemenTestPresenter;
import be.kdg.studeren.view.afnemenTest.AfnemenTestView;
import be.kdg.studeren.view.titleScreen.TitleScreenPresenter;
import be.kdg.studeren.view.titleScreen.TitleScreenView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        Game model = new Game();
        AfnemenTestView view = new AfnemenTestView();
        AfnemenTestPresenter presenter = new AfnemenTestPresenter(model,view);
        Scene scene = new Scene(view, 625, 475);
        scene.getStylesheets().add("/css/Style.css");
        stage.setScene(scene);
        stage.setTitle("Studeren");
        stage.show();
    }
}


