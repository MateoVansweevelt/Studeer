package be.kdg.studeren.model;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Game {
    private List<Vraag> frans;
    private List<Vraag> programmeren;
    private String naam;
    private SoortVraag typeVraag;

    public Game() {
        frans = new ArrayList<>();
        programmeren = new ArrayList<>();
    }

    public void soortVraag(String soortVraag) {
        if (soortVraag.equals("Frans")) {
            typeVraag = SoortVraag.FRANS;
        }
        if (soortVraag.equals("Programmeren")) {
            typeVraag = SoortVraag.PROGRAMMEREN;
        }
    }

    public void toevoegenVraag(String soortVraag) {
        if (soortVraag.equals("Frans")) {
//            frans.add(v);
            System.out.println("toegevoegd!");
        }
        if (soortVraag.equals("Programmeren")) {
//            programmeren.add(v);
            System.out.println("toegevoegd!");
        }
    }

    public void save(String soortVraag) throws FileNotFoundException {
        if (soortVraag.equals("FRANS")) {
            Formatter formatter = new Formatter("vragenFrans.csv");
            for (Vraag fran : frans) {
                formatter.format("%d;%s;%s\n", fran.getVraagId(), fran.getVraag(), fran.getAntwoord());
            }
        }
        if (soortVraag.equals("PROGRAMMEREN")) {
            Formatter formatter = new Formatter("vragenProgrammeren.csv");
            for (Vraag prog : programmeren) {
                formatter.format("%d;%s;%s\n", prog.getVraagId(), prog.getVraag(), prog.getAntwoord());
            }
        }
    }

    public void load(String soortVraag) throws FileNotFoundException {
        int aantalVragen = 10;
        try {
            if (soortVraag.equals("FRANS")) {
                Scanner scanner = new Scanner(new File("vragenFrans.csv"));
                for (int i = 0; i < aantalVragen; i++) {
//                    Random idPicker = new Random(v.getVraagId());
                }
            }
            if (soortVraag.equals("PROGRAMMEREN")) {
//                Random idPicker = new Random(v.getVraagId());
            }
        } catch (FileNotFoundException fnf) {
            System.out.println("er liep iets mis met het uitlezen van de file.");
            System.out.printf("%s", fnf.getCause());
        }
    }

    //getter
    public String getNaam() {
        return naam;
    }

    //setters
    public void setNaam(String naam) {
        this.naam = naam;
    }
}
