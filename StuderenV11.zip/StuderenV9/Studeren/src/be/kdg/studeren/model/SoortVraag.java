package be.kdg.studeren.model;

public enum SoortVraag {
    FRANS, PROGRAMMEREN;
}
