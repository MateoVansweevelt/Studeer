package be.kdg.studeren.model;

public class Vraag {
    private int vraagId;
    private String vraag;
    private String antwoord;

    public Vraag(int vraagId, String vraag, String antwoord) {
        this.vraagId = vraagId;
        this.vraag = vraag;
        this.antwoord = antwoord;
    }

    public int getVraagId() {
        return vraagId;
    }

    public String getVraag() {
        return vraag;
    }

    public String getAntwoord() {
        return antwoord;
    }
}
