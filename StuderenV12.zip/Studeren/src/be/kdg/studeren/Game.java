/*package be.kdg.studeren;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Game extends IngevenVraagEnAntwoord {

    public void start(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Menu menu = new Menu();
        IngevenVraagEnAntwoord outputFrans = new IngevenVraagEnAntwoord();
        IngevenVraagEnAntwoord outputProg = new IngevenVraagEnAntwoord();

        System.out.printf("Geef je naam: ");
        String name = scanner.next();
        Player player = new Player(name);
        player.setNaam(name);

        //menu's in een try statement
        try {

            //eerste menu
            while (!menu.geldigAntwoordEersteMenu) {
                System.out.println(menu.Menu1());
                menu.antwoordPlayerEersteMenu = scanner.nextInt();

                switch (menu.antwoordPlayerEersteMenu) {
                    case 1:
                        //Speler kiest 1 (Gegevens invoeren)
                        menu.geldigAntwoordEersteMenu = true;
                        while (!menu.geldigAntwoordTweedeMenu) {

                            //tweede menu (Voor welk vak wens je gegevens in te geven?)
                            System.out.println(menu.Menu2());
                            menu.antwoordPlayerTweedeMenu = scanner.nextInt();

                            switch(menu.antwoordPlayerTweedeMenu) {
                                case 1:
                                    menu.geldigAntwoordTweedeMenu = true;

                                    // gegevens invullen frans
                                    outputFrans.setVraag();
                                    outputFrans.setAntwoord();
                                    outputFrans.aanmakenBestand();
                                    outputFrans.toevoegenRecords();
                                    outputFrans.sluitbestand();

                                    break;
                                case 2:
                                    menu.geldigAntwoordTweedeMenu = true;

                                    // gegevens invullen programmeren
                                    outputProg.setVraag();
                                    outputProg.setAntwoord();
                                    outputProg.aanmakenBestand();
                                    outputProg.toevoegenRecords();
                                    outputProg.sluitbestand();

                                    break;
                                case 3:
                                    //terug naar vorig menu
                                    menu.geldigAntwoordTweedeMenu = true;
                                    System.out.println(menu.Menu1());
                                    menu.geldigAntwoordEersteMenu = false;
                                    menu.geldigAntwoordTweedeMenu = false;
                                    menu.antwoordPlayerTweedeMenu = scanner.nextInt();
                                    break;
                            }

                        }
                        break;
                    case 2:
                        // Speler kiest 2 (Test afnemen)
                        menu.geldigAntwoordEersteMenu = true;
                            System.out.println(menu.Menu3());
                            while(!menu.geldigAntwoordDerdeMenu) {
                                int antwoordPlayerDerdeMenu = scanner.nextInt();

                                //nog een switch voor input
                                switch (menu.antwoordPlayerDerdeMenu) {
                                    case 1:
                                        menu.geldigAntwoordDerdeMenu = true;

                                        //Test test = new Test();
                                        // TODO: TEST statistiek

                                        break;
                                }

                            }

                        break;

                    case 3:
                        //Speler kiest 3 (afsluiten)
                        menu.geldigAntwoordEersteMenu = true;
                        System.exit(1);
                }
            }
        } catch (InputMismatchException ime) {
            System.out.println("Vul een geldig antwoord in");
            //ime.printStackTrace();
        }
    }
}*/

