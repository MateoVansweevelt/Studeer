package be.kdg.studeren.model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.List;
import java.util.Scanner;

public class Game {

    private String naam;

    private ObservableList<Vraag> vragenFrans;
    private ObservableList<String> alleenVragenFrans;
    private ObservableList<String> alleenAntwoordenFrans;
    private List<Vraag> vragenProgrammeren;
    private List<Vraag> vragenStatistiek;

    boolean lijstAlGeladen;

    //vraag en antwoord variablen die gebruikt worden om doorgegeven worden naar de VraagView
    private String vraagEdit;
    private String antwoordEdit;

    private SoortVraag typeVraag;

    public Game() {
        vragenFrans = FXCollections.observableArrayList();
        alleenVragenFrans = FXCollections.observableArrayList();
        alleenAntwoordenFrans = FXCollections.observableArrayList();
        vragenProgrammeren = new ArrayList<>();
        vragenStatistiek = new ArrayList<>();
        lijstAlGeladen = false;
    }

    public void addVraagFrans(Vraag vraag) {
        vragenFrans.add(vraag);
        alleenVragenFrans.add(vraag.getVraag());
        alleenAntwoordenFrans.add(vraag.getAntwoord());
        System.out.println("VRAAG TOEGEVOEGD");
        saveFrans();
    }

    public void saveFrans() {
        //save method voor de save button in de VraagView
        System.out.println("SAVING...");
        int vraagIdFrans = vragenFrans.size();
        try(Formatter fm = new Formatter("vragen.txt")) {
            for(Vraag vraag: vragenFrans) {
                fm.format("%d,%s,%s\n", vraagIdFrans, vraag.getVraag(), vraag.getAntwoord());
            }
        } catch (IOException ioe) {
            System.out.println("Er is een probleem opgetreden bij het saven.");
        }
    }

/*    public void loadFrans() {
        System.out.println("Loading...");

        //EERST TESTEN OF FILE BESTAAT
        Path pathToFile = Paths.get("vragen.txt");

        if (Files.exists(pathToFile)) {
            try(Scanner s = new Scanner(new File("vragen.txt"))) {
                while (s.hasNext()) {
                    String oneLine = s.nextLine();
                    String[] strings = oneLine.split(",");

                    //print de ingeladen vragen in de console
                    System.out.println("id: " + strings[0] + " Vraag: " + strings[1] + " antwoord: " + strings[2]);
                }
            } catch (IOException ioe) {
                System.out.println("Er is een probleem opgetreden bij het laden.");
            }
        }
    }*/

    public void loadFransListview() {
        System.out.println("Loading...");

        //EERST TESTEN OF FILE BESTAAT
        Path pathToFile = Paths.get("vragen.txt");

        if (Files.exists(pathToFile)) {
            try(Scanner s = new Scanner(new File("vragen.txt"))) {
                while (s.hasNext()) {
                    String oneLine = s.nextLine();
                    String[] strings = oneLine.split(",");

                    //print de ingeladen vragen in de console
                    System.out.println("id: " + strings[0] + " Vraag: " + strings[1] + " antwoord: " + strings[2]);
                    vragenFrans.add(new Vraag(strings[1],strings[2]));
                    alleenVragenFrans.add(strings[1]);
                    alleenAntwoordenFrans.add(strings[2]);
                }
            } catch (IOException ioe) {
                System.out.println("Er is een probleem opgetreden bij het laden.");
            }
        }
    }

    //getters
    public List<Vraag> getVragenFrans() {
        return vragenFrans;
    }

    public List<Vraag> getVragenProgrammeren() {
        return vragenProgrammeren;
    }

    public List<Vraag> getVragenStatistiek() {
        return vragenStatistiek;
    }

    public String getNaam() {
        return naam;
    }

    public String getVraagEdit() {
        return vraagEdit;
    }

    public String getAntwoordEdit() {
        return antwoordEdit;
    }

    public boolean isLijstAlGeladen() {
        return lijstAlGeladen;
    }

    public ObservableList<Vraag> getListFrans() {
        return vragenFrans;
    }

    public ObservableList<String> getAlleenVragenFrans() {
        return alleenVragenFrans;
    }

    public ObservableList<String> getAlleenAntwoordenFrans() {
        return alleenAntwoordenFrans;
    }

    //setters
    public void setNaam(String naam) {
        this.naam = naam;
    }

    public void setVraagEdit(String vraagEdit) {
        this.vraagEdit = vraagEdit;
    }

    public void setAntwoordEdit(String antwoordEdit) {
        this.antwoordEdit = antwoordEdit;
    }

    public void setLijstAlGeladen(boolean lijstAlGeladen) {
        this.lijstAlGeladen = lijstAlGeladen;
    }

    //zoekt het bijpassende antwoord bij de geselecteerde vraag in de listview
    public void setIndex(int index) {
        this.antwoordEdit = getAlleenAntwoordenFrans().get(index);
    }

}
