package be.kdg.studeren.view.vragenList;

import be.kdg.studeren.model.Vraag;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

import java.util.List;

public class VragenListView extends BorderPane {

    ListView<Vraag> lvVragenlijst;
    ListView<String > lvAlleenVragenlijst;

    Button btnTerug;
    Button btnToevoegen;
    List<Vraag> list;


    public VragenListView() {
        initialisatieNodes();
        layoutNodes();
    }

    private void initialisatieNodes() {
        lvVragenlijst = new ListView<Vraag>();
        lvAlleenVragenlijst = new ListView<String>();
        btnTerug = new Button("Terug");
        btnToevoegen = new Button("Vraag Toevoegen");
    }

    private void layoutNodes() {
        VBox vboxVragenlijst = new VBox(lvAlleenVragenlijst,btnTerug, btnToevoegen);
        BorderPane.setAlignment(btnTerug, Pos.CENTER);
        lvVragenlijst.setPrefWidth(250);
        lvVragenlijst.setPrefHeight(500);

        super.setCenter(vboxVragenlijst);

        vboxVragenlijst.setPrefHeight(500);
        vboxVragenlijst.setPrefWidth(500);
        vboxVragenlijst.setPadding(new Insets(50,50,50,50));
        vboxVragenlijst.setSpacing(20);

    }

    ListView getLvVragenlijst() {
        return lvVragenlijst;
    }

    ListView<String> getLvAlleenVragenlijst() {
        return lvAlleenVragenlijst;
    }

    Button getBtnTerug() {
        return btnTerug;
    }

    Button getBtnToevoegen() {
        return btnToevoegen;
    }

}
