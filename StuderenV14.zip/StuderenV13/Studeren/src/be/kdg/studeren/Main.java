package be.kdg.studeren;

import be.kdg.studeren.model.Game;
import be.kdg.studeren.view.titleScreen.TitleScreenPresenter;
import be.kdg.studeren.view.titleScreen.TitleScreenView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        Game model = new Game();
        TitleScreenView view = new TitleScreenView();
        TitleScreenPresenter presenter = new TitleScreenPresenter(model,view);
        Scene scene = new Scene(view, 625, 475);
        scene.getStylesheets().add("/css/Style.css");
        stage.setScene(scene);
        stage.setTitle("Studeren");
        stage.show();
    }
}


