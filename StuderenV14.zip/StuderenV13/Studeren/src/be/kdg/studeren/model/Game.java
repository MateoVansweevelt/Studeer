package be.kdg.studeren.model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class Game {
    boolean lijstFransAlGeladen;
    boolean lijstProgrammerenAlGeladen;
    boolean lijstFransGewijzigd;
    boolean lijstProgrammerenGewijzigd;
    private String naam;
    //frans
    private ObservableList<Vraag> vragenFrans;
    private ObservableList<String> alleenVragenFrans;
    private ObservableList<String> alleenAntwoordenFrans;
    //programmeren
    private ObservableList<Vraag> vragenProgrammeren;
    private ObservableList<String> alleenVragenProgrammeren;
    private ObservableList<String> alleenAntwoordenProgrammeren;
    private List<Vraag> vragenStatistiek;
    //vraag en antwoord variablen die gebruikt worden om doorgegeven worden naar de VraagView
    private String vraagEdit;
    private String antwoordEdit;

    private SoortVraag typeVraag;

    private int index;
    private int geselecteerdeVraag;
    String antwoordUser;

    public Game() {
        vragenFrans = FXCollections.observableArrayList();
        alleenVragenFrans = FXCollections.observableArrayList();
        alleenAntwoordenFrans = FXCollections.observableArrayList();

        vragenProgrammeren = FXCollections.observableArrayList();
        alleenVragenProgrammeren = FXCollections.observableArrayList();
        alleenAntwoordenProgrammeren = FXCollections.observableArrayList();

        vragenStatistiek = new ArrayList<>();
        lijstFransAlGeladen = false;
        lijstProgrammerenAlGeladen = false;

        lijstFransGewijzigd = false;
        lijstProgrammerenGewijzigd = false;
    }

/*    public void soortVraag(String soortVraag) {
        if (soortVraag.equals("Frans")) {
            typeVraag = SoortVraag.FRANS;
        }
        if (soortVraag.equals("Programmeren")) {
            typeVraag = SoortVraag.PROGRAMMEREN;
        }
    }*/

    public String vraagKiezen() {
        String vraag = "";
        if (getTypeVraag() == SoortVraag.FRANS) {
            loadFransListview();
            Random random = new Random();
            for (int i = 0; i <= 15; i++) {
                geselecteerdeVraag = random.nextInt(vragenFrans.size());
                vraag = getAlleenVragenFrans().get(geselecteerdeVraag);
            }
            return vraag;
        }
        if (getTypeVraag() == SoortVraag.PROGRAMMEREN) {
            loadProgrammerenListview();
            Random random = new Random();
            for (int i = 0; i <= 15; i++) {
                geselecteerdeVraag = random.nextInt(vragenProgrammeren.size());
                vraag = getAlleenVragenProgrammeren().get(geselecteerdeVraag);
            }
        }
        return vraag;
    }

    public boolean controleerAntwoord() {
        String antwoord = getAlleenAntwoordenFrans().get(geselecteerdeVraag);
        if (getTypeVraag() == SoortVraag.FRANS) {
            if (antwoord.equals(antwoordUser)) {
                return true;
            }
        }
        if (getTypeVraag() == SoortVraag.PROGRAMMEREN) {
            if (antwoord.equals(antwoordUser)) {
                return true;
            }
        }
        return false;
    }

    public void addVraagFrans(Vraag vraag) {
        vragenFrans.add(vraag);
        alleenVragenFrans.add(vraag.getVraag());
        alleenAntwoordenFrans.add(vraag.getAntwoord());
        System.out.println("VRAAG TOEGEVOEGD");
        saveFrans();
    }

    public void addVraagProgrammeren(Vraag vraag) {
        vragenProgrammeren.add(vraag);
        alleenVragenProgrammeren.add(vraag.getVraag());
        alleenAntwoordenProgrammeren.add(vraag.getAntwoord());
        System.out.println("VRAAG TOEGEVOEGD");
        saveProgrammeren();
    }

    public void removeVraagFrans(Vraag vraag) {
        vragenFrans.remove(vraag);
        alleenVragenFrans.remove(vraag.getVraag());
        alleenAntwoordenFrans.remove(vraag.getAntwoord());
        System.out.println("VRAAG VERWIJDERD");
        saveFrans();
    }

    //save method na het toevoegen van een vraag
    public void saveFrans() {
        System.out.println("SAVING...");

        //int vraagIdFrans = vragenFrans.size();
        int vraagIdFrans = 1;

        try (Formatter fm = new Formatter("vragenFrans.txt")) {
            for (Vraag vraag : vragenFrans) {
                fm.format("%d,%s,%s\n", vraagIdFrans, vraag.getVraag(), vraag.getAntwoord());
                vraagIdFrans++;
            }
        } catch (IOException ioe) {
            System.out.println("Er is een probleem opgetreden bij het saven.");
        }
    }

    public void saveProgrammeren() {
        System.out.println("SAVING...");

        int vraagIdProgrammeren = 1;

        try (Formatter fm = new Formatter("vragenProgrammeren.txt")) {
            for (Vraag vraag : vragenProgrammeren) {
                fm.format("%d,%s,%s\n", vraagIdProgrammeren, vraag.getVraag(), vraag.getAntwoord());
                vraagIdProgrammeren++;
            }
        } catch (IOException ioe) {
            System.out.println("Er is een probleem opgetreden bij het saven.");
        }
    }

    //save method voor de save button in de VraagView
    public void saveEditFrans(int index, String vraag, String antwoord) {
        System.out.println("SAVING...");

        int vraagIdFrans = 1;
        vragenFrans.set(getIndex(), new Vraag(vraag, antwoord));

        try (Formatter fm = new Formatter("vragenFrans.txt")) {
            for (Vraag v : vragenFrans) {
                fm.format("%d,%s,%s\n", vraagIdFrans, v.getVraag(), v.getAntwoord());
                vraagIdFrans++;
            }
        } catch (IOException ioe) {
            System.out.println("Er is een probleem opgetreden bij het saven.");
        }
    }

    public void saveEditProgrammeren(int index, String vraag, String antwoord) {
        System.out.println("SAVING...");

        int vraagIdProgrammeren = 1;
        vragenProgrammeren.set(getIndex(), new Vraag(vraag, antwoord));

        try (Formatter fm = new Formatter("vragenProgrammeren.txt")) {
            for (Vraag v : vragenProgrammeren) {
                fm.format("%d,%s,%s\n", vraagIdProgrammeren, v.getVraag(), v.getAntwoord());
                vraagIdProgrammeren++;
            }
        } catch (IOException ioe) {
            System.out.println("Er is een probleem opgetreden bij het saven.");
        }
    }

    public void loadFransListview() {
        System.out.println("Loading...");

        //EERST TESTEN OF FILE BESTAAT
        Path pathToFile = Paths.get("vragenFrans.txt");

        if (Files.exists(pathToFile)) {
            try (Scanner s = new Scanner(new File("vragenFrans.txt"))) {
                while (s.hasNext()) {
                    String oneLine = s.nextLine();
                    String[] strings = oneLine.split(",");

                    //print de ingeladen vragen in de console
                    System.out.println("id: " + strings[0] + " Vraag: " + strings[1] + " antwoord: " + strings[2]);
                    vragenFrans.add(new Vraag(strings[1], strings[2]));
                    alleenVragenFrans.add(strings[1]);
                    alleenAntwoordenFrans.add(strings[2]);
                }
            } catch (IOException ioe) {
                System.out.println("Er is een probleem opgetreden bij het laden.");
                System.out.printf("%s", ioe.getCause());
            }
        }
    }

    public void loadProgrammerenListview() {
        System.out.println("Loading...");

        //EERST TESTEN OF FILE BESTAAT
        Path pathToFile = Paths.get("vragenProgrammeren.txt");

        if (Files.exists(pathToFile)) {
            try (Scanner s = new Scanner(new File("vragenProgrammeren.txt"))) {
                while (s.hasNext()) {
                    String oneLine = s.nextLine();
                    String[] strings = oneLine.split(",");

                    //print de ingeladen vragen in de console
                    System.out.println("id: " + strings[0] + " Vraag: " + strings[1] + " antwoord: " + strings[2]);
                    vragenProgrammeren.add(new Vraag(strings[1], strings[2]));
                    alleenVragenProgrammeren.add(strings[1]);
                    alleenAntwoordenProgrammeren.add(strings[2]);
                }
            } catch (IOException ioe) {
                System.out.println("Er is een probleem opgetreden bij het laden.");
            }
        }
    }

/*    public void UpdateListviewFrans(){
        //laad de vragen van de file in een ObservableList
        if(!isLijstFransAlGeladen()) {
            //mag maar 1 keer uitgevoerd worden
            loadFransListview();
            setLijstFransAlGeladen(true);
        }
    }

    public void UpdateListViewProgrammeren() {
        //laad de vragen van de file in een ObservableList
        if(!isLijstProgrammerenAlGeladen()) {
            //mag maar 1 keer uitgevoerd worden
            loadProgrammerenListview();
            setLijstProgrammerenAlGeladen(true);
        }
    }*/

    //getters
    public List<Vraag> getVragenFrans() {
        return vragenFrans;
    }

    public List<Vraag> getVragenProgrammeren() {
        return vragenProgrammeren;
    }

    public List<Vraag> getVragenStatistiek() {
        return vragenStatistiek;
    }

    public String getNaam() {
        return naam;
    }

    //setters
    public void setNaam(String naam) {
        this.naam = naam;
    }

    public String getVraagEdit() {
        return vraagEdit;
    }

    public void setVraagEdit(String vraagEdit) {
        this.vraagEdit = vraagEdit;
    }

    public String getAntwoordEdit() {
        return antwoordEdit;
    }

    public void setAntwoordEdit(String antwoordEdit) {
        this.antwoordEdit = antwoordEdit;
    }

    public void setAntwoordUser(String antwoordUser) {
        this.antwoordUser = antwoordUser;
    }

    public boolean isLijstFransAlGeladen() {
        return lijstFransAlGeladen;
    }

    public void setLijstFransAlGeladen(boolean lijstFransAlGeladen) {
        this.lijstFransAlGeladen = lijstFransAlGeladen;
    }

    public boolean isLijstProgrammerenAlGeladen() {
        return lijstProgrammerenAlGeladen;
    }

    public void setLijstProgrammerenAlGeladen(boolean lijstProgrammerenAlGeladen) {
        this.lijstProgrammerenAlGeladen = lijstProgrammerenAlGeladen;
    }

    public boolean isLijstFransGewijzigd() {
        return lijstFransGewijzigd;
    }

    public void setLijstFransGewijzigd(boolean lijstFransGewijzigd) {
        this.lijstFransGewijzigd = lijstFransGewijzigd;
    }

    public boolean isLijstProgrammerenGewijzigd() {
        return lijstProgrammerenGewijzigd;
    }

    public void setLijstProgrammerenGewijzigd(boolean lijstProgrammerenGewijzigd) {
        this.lijstProgrammerenGewijzigd = lijstProgrammerenGewijzigd;
    }

    public SoortVraag getTypeVraag() {
        return typeVraag;
    }

    //wordt gebruikt als vraag + antwoord in de listview moet worden weergegeven
    public ObservableList<Vraag> getListFrans() {
        return vragenFrans;
    }

    public ObservableList<Vraag> getListProgrammeren() {
        return vragenProgrammeren;
    }

    public ObservableList<String> getAlleenVragenFrans() {
        return alleenVragenFrans;
    }

    public ObservableList<String> getAlleenAntwoordenFrans() {
        return alleenAntwoordenFrans;
    }

    public ObservableList<String> getAlleenVragenProgrammeren() {
        return alleenVragenProgrammeren;
    }

    public ObservableList<String> getAlleenAntwoordenProgrammeren() {
        return alleenAntwoordenProgrammeren;
    }

    public int getIndex() {
        return index;
    }

    //zoekt het bijpassende antwoord bij de geselecteerde vraag in de listview
    public int setIndex(int index) {
        if (getTypeVraag() == (SoortVraag.FRANS)) {
            this.vraagEdit = getAlleenVragenFrans().get(index);
            this.antwoordEdit = getAlleenAntwoordenFrans().get(index);
        } else if (getTypeVraag() == (SoortVraag.PROGRAMMEREN)) {
            this.vraagEdit = getAlleenVragenProgrammeren().get(index);
            this.antwoordEdit = getAlleenAntwoordenProgrammeren().get(index);
        }
        return this.index = index;
    }

    public SoortVraag setTypeVraag(SoortVraag typeVraag) {
        return this.typeVraag = typeVraag;
    }
}
