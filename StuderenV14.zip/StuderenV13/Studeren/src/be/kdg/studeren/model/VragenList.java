package be.kdg.studeren.model;

import java.util.ArrayList;
import java.util.Formatter;
import java.util.List;

public class VragenList {
    private List<Vraag> vragen;

    public VragenList(){
        vragen = new ArrayList<>();
    }

    public void addVraag(String vraag, String antwoord){
        vragen.add(new Vraag(vraag,antwoord));
        System.out.println("Vraag toegevoegd");
    }

    public List<Vraag> getVragen() {
        return vragen;
    }
}
