package be.kdg.studeren.view.afnemenTest;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.*;

public class AfnemenTestView extends BorderPane {
    private Label lblTestAfnemen;
    private Label lblVraag;
    private TextArea taAntwoordVlak;
    private Button btnControleer;
    private Button btnPause;
    private Button btnTerug;

    public AfnemenTestView() {
        initialisatieNodes();
        layoutNodes();
    }

    private void initialisatieNodes() {
        lblTestAfnemen = new Label("Test Afnemen");
        lblVraag = new Label("yeet");
        taAntwoordVlak = new TextArea();
        btnPause = new Button("Pauze");
        btnControleer = new Button("Controleer");
        btnTerug = new Button("Terug");
    }

    private void layoutNodes() {
        HBox hBoxTop = new HBox();
        Region regionTop = new Region();
        HBox.setHgrow(regionTop, Priority.ALWAYS);
        lblTestAfnemen.setId("topLeft");
        hBoxTop.getChildren().addAll(lblTestAfnemen, regionTop);
        hBoxTop.setMargin(lblTestAfnemen, new Insets(10));
        this.setTop(hBoxTop);
        VBox vBoxVraag = new VBox();
        vBoxVraag.getChildren().add(lblVraag);
        lblVraag.setId("vraag");
        VBox vBoxAntwoord = new VBox();
        vBoxAntwoord.getChildren().add(taAntwoordVlak);
        taAntwoordVlak.setId("antwoord");
        VBox vBox = new VBox();
        vBox.getChildren().addAll(vBoxVraag, vBoxAntwoord);
        this.setCenter(vBox);
        HBox hBox = new HBox();
        hBox.getChildren().addAll(btnTerug, btnControleer);
        hBox.setMargin(btnTerug, new Insets(20));
        hBox.setMargin(btnControleer, new Insets(20));
        hBox.setSpacing(400);
        this.setBottom(hBox);
    }

    public void setLblVraag(Label lblVraag) {
        this.lblVraag = lblVraag;
    }

    TextArea getTaAntwoordVlak() {
        return taAntwoordVlak;
    }

    Label getLblTestAfnemen() {
        return lblTestAfnemen;
    }

    Label getLblVraag() {
        return lblVraag;
    }

    Button getBtnControleer() {
        return btnControleer;
    }

    Button getBtnPause() {
        return btnPause;
    }

    Button getBtnTerug() {
        return btnTerug;
    }
}
