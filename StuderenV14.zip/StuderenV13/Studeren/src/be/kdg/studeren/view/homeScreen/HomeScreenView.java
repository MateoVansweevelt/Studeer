package be.kdg.studeren.view.homeScreen;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class HomeScreenView extends VBox {
    Button btnTestAfnemen;
    Button btnGegevensInvoeren;
    Button btnAfsluiten;
    Label lblHighscores;
    Label lblNaam;

    public HomeScreenView() {
        initialisatieNodes();
        layoutNodes();
    }

    private void initialisatieNodes() {
        btnTestAfnemen = new Button("Test Afnemen");
        btnGegevensInvoeren = new Button("Gegevens Invoeren");
        btnAfsluiten = new Button("Afsluiten");
        lblHighscores = new Label("Highscores:");
        lblNaam = new Label("Naam: ");
    }

    private void layoutNodes() {
        setPrefSize(400, 400);
        this.setSpacing(10);
        this.btnTestAfnemen.setMinWidth(100);
        btnTestAfnemen.setId("customButton");
        this.btnGegevensInvoeren.setMinWidth(100);
        btnGegevensInvoeren.setId("customButton");
        this.btnAfsluiten.setMinWidth(100);
        btnAfsluiten.setId("customButton");
        this.getChildren().addAll(lblNaam,btnTestAfnemen, btnGegevensInvoeren, btnAfsluiten);
        this.setAlignment(Pos.CENTER);
    }

    Button getBtnTestAfnemen() {
        return btnTestAfnemen;
    }

    Button getBtnGegevensInvoeren() {
        return btnGegevensInvoeren;
    }

    Button getBtnAfsluiten() {
        return btnAfsluiten;
    }

    Label getLblHighscores() {
        return lblHighscores;
    }

    Label getLblNaam() {
        return lblNaam;
    }
}
