package be.kdg.studeren.view.testKiezen;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;

public class TestKiezenView extends VBox {
    Button btnFrans;
    Button btnProgrammeren;
    Button btnAfsluiten;

    public TestKiezenView() {
        initialisatieNodes();
        layoutNodes();
    }

    private void initialisatieNodes() {
        btnFrans = new Button("Frans");
        btnProgrammeren = new Button("Programmeren");
        btnAfsluiten = new Button("Afsluiten");
    }

    private void layoutNodes() {
        setPrefSize(400, 400);
        this.setSpacing(10);
        this.btnFrans.setMinWidth(100);
        btnFrans.setId("customButton");
        this.btnProgrammeren.setMinWidth(100);
        btnProgrammeren.setId("customButton");
        this.btnAfsluiten.setMinWidth(100);
        btnAfsluiten.setId("customButton");
        this.getChildren().addAll(btnFrans, btnProgrammeren);
        this.setAlignment(Pos.CENTER);
    }

    Button getBtnFrans() {
        return btnFrans;
    }

    Button getBtnProgrammeren() {
        return btnProgrammeren;
    }
}
