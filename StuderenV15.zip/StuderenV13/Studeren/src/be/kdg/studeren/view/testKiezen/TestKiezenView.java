package be.kdg.studeren.view.testKiezen;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class TestKiezenView extends BorderPane {
    Label lblVakKiezen;
    Button btnFrans;
    Button btnProgrammeren;
    Button btnTerug;

    public TestKiezenView() {
        initializeNodes();
        layoutNodes();
    }

    private void initializeNodes() {
        lblVakKiezen = new Label("Test Kiezen");
        btnFrans = new Button("Frans");
        btnProgrammeren = new Button("Programmeren");
        btnTerug = new Button("Terug");
    }

    private void layoutNodes() {
        this.setTop(lblVakKiezen);
        lblVakKiezen.setId("topLeft");
        VBox vbox = new VBox();
        vbox.setSpacing(10);
        vbox.getChildren().addAll(btnFrans, btnProgrammeren);
        vbox.setAlignment(Pos.CENTER);
        btnFrans.setId("customButton");
        btnProgrammeren.setId("customButton");
        this.setCenter(vbox);
        this.setBottom(btnTerug);
        this.setStyle("-fx-alignment: left");
        this.setStyle("-fx-padding: 20px");
    }

    Button getBtnFrans() {
        return btnFrans;
    }

    Button getBtnProgrammeren() {
        return btnProgrammeren;
    }

    Button getBtnTerug() {
        return btnTerug;
    }
}
