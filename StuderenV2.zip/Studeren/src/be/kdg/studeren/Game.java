package be.kdg.studeren;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Game extends Menu {
    public static void main(String[] args) {
        //scanner
        Scanner scanner = new Scanner(System.in);

        //Begin spel

        Menu menu = new Menu();

        System.out.printf("Geef je naam: ");
        String name = scanner.next();
        Player player = new Player(name);
        // System.out.println("Hello " + player.getNaam());

        //eerste keuzemenu TODO: formatting
        boolean geldigAntwoordEersteMenu = false;
        boolean geldigAntwoordTweedeMenu = false;

            //eerste menu
            while (!geldigAntwoordEersteMenu) {

                System.out.println(menu.Menu1());

                int antwoordPlayerEersteMenu = 0;
                int antwoordPlayerTweedeMenu = 0;
                try {
                    antwoordPlayerEersteMenu = scanner.nextInt();

                    if (antwoordPlayerEersteMenu == 1) {
                        geldigAntwoordEersteMenu = true;
                        //tweede menu (antwoord a bij eerste menu)
                        while (!geldigAntwoordTweedeMenu) {

                            System.out.println(menu.Menu2());
                            antwoordPlayerTweedeMenu = scanner.nextInt();

                            if (antwoordPlayerTweedeMenu == 1) {
                                geldigAntwoordTweedeMenu = true;

                            } else if (antwoordPlayerTweedeMenu == 2) {
                                geldigAntwoordTweedeMenu = true;

                            } else if (antwoordPlayerTweedeMenu == 3) {
                                geldigAntwoordTweedeMenu = true;
                                System.out.println(menu.Menu1());

                            } else {

                            }
                        }

                    } else if (antwoordPlayerEersteMenu == 2) {
                        geldigAntwoordEersteMenu = true;
                        int antwoordPlayerDerdeMenu = scanner.nextInt();

                    } else {
                        System.out.println("Geef een geldig antwoordPlayerEersteMenu");
                    }
                } catch (InputMismatchException ime) {
                    System.out.println("NIET GOED HE");
                    scanner.reset();
                    //ime.printStackTrace();
                }
            }

    }
}
