package be.kdg.studeren;

import java.io.FileNotFoundException;
import java.util.Formatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class IngevenVraagEnAntwoord {
    private String vraag;
    private String antwoord;
    private int aantalVragen;
    private Scanner scanner = new Scanner(System.in);
    private Formatter formatterFrans;
    private Formatter formatterProgrammeren;
    Map<String, String> records = new HashMap<>();

    public int getAantalVragen() {
        return aantalVragen;
    }

    public void setAantalVragen() {
        System.out.print("Geef het aantal vragen: ");
        aantalVragen = scanner.nextInt();
    }

    public void setVraag() {
        System.out.print("Geef de vraag in: ");
        vraag = scanner.next();
    }

    public void setAntwoord() {
        System.out.print("Geef het antwoord in: ");
        antwoord = scanner.next();
    }

    public void aanmakenBestandFrans() {
        try {
            formatterFrans = new Formatter("logFrans.csv");
        } catch (FileNotFoundException fnfe) {
            System.out.println(fnfe.getCause().getMessage());
        }
    }

    public void aanmakenBestandProgrammeren() {
        try {
            formatterProgrammeren = new Formatter("logProgrammeren.csv");
        } catch (FileNotFoundException fnfe) {
            System.out.println(fnfe.getCause().getMessage());
        }
    }

    public void toevoegenRecords() {
        records.put(vraag, antwoord);
    }

    public void sluitbestandFrans() {
        formatterFrans.close();
    }

    public void sluitbestandProgrammeren() {
        formatterProgrammeren.close();
    }
}

