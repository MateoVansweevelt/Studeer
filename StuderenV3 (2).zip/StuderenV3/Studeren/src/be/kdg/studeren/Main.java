package be.kdg.studeren;

import be.kdg.studeren.model.HomeScreen;
import be.kdg.studeren.view.homeScreen.HomeScreenPresenter;
import be.kdg.studeren.view.homeScreen.HomeScreenView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        HomeScreen hs = new HomeScreen();
        HomeScreenView hsv = new HomeScreenView();
        HomeScreenPresenter hsp = new HomeScreenPresenter(hsv, hs);
        Scene scene = new Scene(hsv);
        stage.setScene(scene);
        stage.setTitle("Studeren");
        stage.show();
    }
}


