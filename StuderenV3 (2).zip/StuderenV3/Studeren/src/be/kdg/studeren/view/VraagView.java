package be.kdg.studeren.view;

public class VraagView {
}
