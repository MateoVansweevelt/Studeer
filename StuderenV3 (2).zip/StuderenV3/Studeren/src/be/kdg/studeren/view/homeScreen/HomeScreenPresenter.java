package be.kdg.studeren.view.homeScreen;

import be.kdg.studeren.model.HomeScreen;

public class HomeScreenPresenter {
    private HomeScreenView view;
    private HomeScreen model;

    public HomeScreenPresenter(HomeScreenView view, HomeScreen model) {
        addEventHandlers();
        updateView();
    }

    private void updateView() {

    }

    private void addEventHandlers() {

    }
}
