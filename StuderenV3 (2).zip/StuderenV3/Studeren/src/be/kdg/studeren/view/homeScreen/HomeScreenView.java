package be.kdg.studeren.view.homeScreen;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class HomeScreenView extends VBox {
    private Button btnTestAfnemen;
    private Button btnGegevensInvoeren;
    private Button btnAfsluiten;
    private Label lblHighScore;
    private Label lblHighScoreList;

    public HomeScreenView() {
        initializeNodes();
        layoutNodes();
    }

    private void initializeNodes() {
        btnTestAfnemen = new Button("Test Afnemen");
//        btnTestAfnemen.setStyle("-fx-scale-x: 100");
        btnGegevensInvoeren = new Button("Gegevens Invoeren");
//        btnTestAfnemen.setStyle("-fx-scale-x: 100");
        btnAfsluiten = new Button("Afsluiten");
//        btnTestAfnemen.setStyle("-fx-scale-x: 100");
        lblHighScore = new Label("Highscores");
        lblHighScoreList = new Label();
    }

    private void layoutNodes() {
        VBox vBoxlblhighscore = new VBox();
        vBoxlblhighscore.getChildren().addAll(lblHighScore, lblHighScoreList);
        VBox vBoxButtons = new VBox();
        this.setAlignment(Pos.CENTER);
        this.setSpacing(20);
        this.setPadding(new Insets(20));
        this.btnTestAfnemen.setMaxWidth(Double.MAX_VALUE);
        this.btnGegevensInvoeren.setMaxWidth(Double.MAX_VALUE);
        this.btnAfsluiten.setMaxWidth(Double.MAX_VALUE);
        vBoxButtons.getChildren().addAll(btnGegevensInvoeren, btnTestAfnemen, btnAfsluiten);
        super.getChildren().addAll(vBoxlblhighscore,vBoxButtons);
    }

    Button getBtnTestAfnemen() {
        return btnTestAfnemen;
    }

    Button getBtnGegevensInvoeren() {
        return btnGegevensInvoeren;
    }

    Button getBtnAfsluiten() {
        return btnAfsluiten;
    }

    Label getLblHighScore() {
        return lblHighScore;
    }

    Label getLblHighScoreList() {
        return lblHighScoreList;
    }
}
