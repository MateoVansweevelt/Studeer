package be.kdg.studeren.view.vragenList;

public class VragenListView {
}
