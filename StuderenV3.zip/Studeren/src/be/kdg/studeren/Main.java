package be.kdg.studeren;

public class Main extends Game {
    public static void main(String[] args) {
        Game game = new Game();
        game.start(args);
    }
}


