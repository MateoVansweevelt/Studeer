package be.kdg.studeren;

import be.kdg.studeren.model.TitleScreen;
import be.kdg.studeren.model.VragenList;
import be.kdg.studeren.view.titleScreen.TitleScreenPresenter;
import be.kdg.studeren.view.titleScreen.TitleScreenView;
import be.kdg.studeren.view.vragenList.VragenListPresenter;
import be.kdg.studeren.view.vragenList.VragenListView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
    public static void main(String[] args) {
        launch(args);
        Game game = new Game();
        game.start(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
/*        TitleScreen model = new TitleScreen();
        TitleScreenView view = new TitleScreenView();
        TitleScreenPresenter presenter = new TitleScreenPresenter(model,view);*/

        VragenList model = new VragenList();
        VragenListView view = new VragenListView();
        VragenListPresenter presenter = new VragenListPresenter(model,view);

        Scene scene = new Scene(view);
        stage.setScene(scene);
        stage.setTitle("Studeren");
        stage.show();
    }
}


