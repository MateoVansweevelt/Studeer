package be.kdg.studeren;

public class MainHack {
    public static void main(String[] args) {
        Main.main(args);
    }
}
