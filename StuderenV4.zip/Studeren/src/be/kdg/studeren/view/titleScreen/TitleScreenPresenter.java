package be.kdg.studeren.view.titleScreen;

import be.kdg.studeren.model.TitleScreen;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class TitleScreenPresenter {
    private TitleScreen model;
    private TitleScreenView view;

    public TitleScreenPresenter(TitleScreen model, TitleScreenView view) {
        this.model = model;
        this.view = view;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        view.getBtnVerder().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

            }
        });
    }

    private void updateView() {

    }



}
