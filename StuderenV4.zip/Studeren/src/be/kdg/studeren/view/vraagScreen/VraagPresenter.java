package be.kdg.studeren.view.vraagScreen;

import be.kdg.studeren.model.Vraag;
import be.kdg.studeren.model.VragenList;
import be.kdg.studeren.view.vragenList.VragenListView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

public class VraagPresenter {
    private Vraag model;
    private VraagView view;

    //private VragenList modelVragenList = new VragenList();
    private VragenListView viewVragenList = new VragenListView();

    public VraagPresenter(Vraag model, VraagView view) {
        this.model = model;
        this.view = view;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        view.getBtnTerug().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                view.getScene().setRoot(viewVragenList);
            }
        });

    }

    private void updateView() {

    }

}
