package be.kdg.studeren;

import be.kdg.studeren.model.HomeScreen;
import be.kdg.studeren.view.homeScreen.HomeScreenPresenter;
import be.kdg.studeren.view.homeScreen.HomeScreenView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
    public static void main(String[] args) {
        launch(args);
        Game game = new Game();
        game.start(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        HomeScreen model = new HomeScreen();
        HomeScreenView view = new HomeScreenView();
        HomeScreenPresenter presenter = new HomeScreenPresenter(model, view);
        Scene scene = new Scene(view);
        stage.setScene(scene);
        stage.setTitle("Studeren");
        stage.show();
    }
}


