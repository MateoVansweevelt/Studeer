package be.kdg.studeren.view.afnemenTest;

import javafx.scene.layout.BorderPane;

public class AfnemenTestView extends BorderPane {
    public AfnemenTestView() {
        initializeNodes();
        layoutNodes();
    }

    private void layoutNodes() {

    }

    private void initializeNodes() {

    }
}
