package be.kdg.studeren.view.gegevensInvoeren;

public class GegevensInvoerenPresenter {
}
