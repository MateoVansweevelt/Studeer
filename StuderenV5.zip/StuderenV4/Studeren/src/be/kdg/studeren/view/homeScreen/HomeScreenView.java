package be.kdg.studeren.view.homeScreen;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class HomeScreenView extends VBox {
    private Button btnTestAfnemen;
    private Button btnGegevensInvoeren;
    private Button btnAfsluiten;
    private Label lblHighScore;
    private Label lblHighScoreList;

    public HomeScreenView() {
        initializeNodes();
        layoutNodes();
    }

    private void initializeNodes() {
        btnTestAfnemen = new Button("Test Afnemen");
        btnGegevensInvoeren = new Button("Gegevens Invoeren");
        btnAfsluiten = new Button("Afsluiten");
        lblHighScore = new Label("Highscores");
        lblHighScoreList = new Label();
    }

    private void layoutNodes() {
        VBox vBoxlblhighscore = new VBox();
        HBox hbox = new HBox();
        vBoxlblhighscore.getChildren().addAll(lblHighScore, lblHighScoreList);
        VBox vBoxButtons = new VBox();
        vBoxButtons.getChildren().addAll(btnGegevensInvoeren, btnTestAfnemen, btnAfsluiten);
        super.getChildren().addAll(vBoxlblhighscore, vBoxButtons);
    }

    Button getBtnTestAfnemen() {
        return btnTestAfnemen;
    }

    Button getBtnGegevensInvoeren() {
        return btnGegevensInvoeren;
    }

    Button getBtnAfsluiten() {
        return btnAfsluiten;
    }

    Label getLblHighScore() {
        return lblHighScore;
    }

    Label getLblHighScoreList() {
        return lblHighScoreList;
    }
}
