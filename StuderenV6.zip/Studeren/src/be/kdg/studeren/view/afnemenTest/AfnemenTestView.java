package be.kdg.studeren.view.afnemenTest;


import javafx.scene.layout.BorderPane;

public class AfnemenTestView extends BorderPane {
    public AfnemenTestView() {
        initialisatieNodes();
        layoutNodes();
    }

    private void initialisatieNodes() {

    }

    private void layoutNodes() {


    }
}
