package be.kdg.studeren.view.endScreen;

public class EndScreenPresenter {
}
