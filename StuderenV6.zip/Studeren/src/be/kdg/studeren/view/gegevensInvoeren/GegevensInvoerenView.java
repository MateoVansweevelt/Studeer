package be.kdg.studeren.view.gegevensInvoeren;

import javafx.scene.layout.BorderPane;

public class GegevensInvoerenView extends BorderPane {
    public GegevensInvoerenView() {
        initializeNodes();
        layoutNodes();
    }

    private void layoutNodes() {

    }

    private void initializeNodes() {

    }
}
