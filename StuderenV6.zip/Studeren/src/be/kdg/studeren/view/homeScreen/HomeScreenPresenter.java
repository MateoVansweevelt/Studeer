package be.kdg.studeren.view.homeScreen;

import be.kdg.studeren.model.HomeScreen;
import be.kdg.studeren.view.afnemenTest.AfnemenTestView;
import be.kdg.studeren.view.gegevensInvoeren.GegevensInvoerenView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

public class HomeScreenPresenter {

    private HomeScreen model;
    private HomeScreenView view;

    private AfnemenTestView afnemenTestView = new AfnemenTestView();
    private GegevensInvoerenView gegevensInvoerenView = new GegevensInvoerenView();

    public HomeScreenPresenter(HomeScreen model, HomeScreenView view) {
        this.model = model;
        this.view = view;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        view.getBtnAfsluiten().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                System.exit(0);
            }
        });
        view.getBtnTestAfnemen().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                view.getScene().setRoot(afnemenTestView);
            }
        });
        view.getBtnGegevensInvoeren().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                view.getScene().setRoot(gegevensInvoerenView);
            }
        });
    }


    private void updateView() {

    }

}
