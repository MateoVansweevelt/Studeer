package be.kdg.studeren.view.homeScreen;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class HomeScreenView extends BorderPane {
    Button btnTestAfnemen;
    Button btnGegevensInvoeren;
    Button btnAfsluiten;
    Label lblHighscores;
    Label lblNaam;

    public HomeScreenView() {
        initialisatieNodes();
        layoutNodes();
    }

    private void initialisatieNodes() {
        btnTestAfnemen = new Button("Test Afnemen");
        btnGegevensInvoeren = new Button("Gegevens Invoeren");
        btnAfsluiten = new Button("Afsluiten");
        lblHighscores = new Label("Highscores:");
        lblNaam = new Label("Naam: ");
    }

    private void layoutNodes() {

        VBox vboxButtons = new VBox(btnGegevensInvoeren,btnTestAfnemen,btnAfsluiten);
       // VBox vboxLabels = new VBox(lblNaam,lblHighscores);

        btnTestAfnemen.setPrefWidth(200);
        btnGegevensInvoeren.setPrefWidth(200);
        btnAfsluiten.setPrefWidth(200);

        super.setCenter(vboxButtons);
        vboxButtons.setPrefHeight(500);
        vboxButtons.setPrefWidth(500);
        vboxButtons.setPadding(new Insets(150,150,25,25));
        vboxButtons.setSpacing(60);

    }

    Button getBtnTestAfnemen() {
        return btnTestAfnemen;
    }

    Button getBtnGegevensInvoeren() {
        return btnGegevensInvoeren;
    }

    Button getBtnAfsluiten() {
        return btnAfsluiten;
    }

    Label getLblHighscores() {
        return lblHighscores;
    }

    Label getLblNaam() {
        return lblNaam;
    }
}
