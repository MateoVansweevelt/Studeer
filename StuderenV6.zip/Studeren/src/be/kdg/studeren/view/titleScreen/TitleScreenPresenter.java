package be.kdg.studeren.view.titleScreen;

import be.kdg.studeren.model.HomeScreen;
import be.kdg.studeren.model.TitleScreen;
import be.kdg.studeren.view.homeScreen.HomeScreenView;
import be.kdg.studeren.view.vragenList.VragenListView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;

public class TitleScreenPresenter {
    private TitleScreen model;
    private TitleScreenView view;

    //private HomeScreen modelHomeScreen = new HomeScreen();
    private HomeScreenView viewHomeScreen = new HomeScreenView();

    public TitleScreenPresenter(TitleScreen model, TitleScreenView view) {
        this.model = model;
        this.view = view;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        view.getBtnVerder().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if(view.getTfNaam().getText() == null ||view.getTfNaam().getText().trim().isEmpty()) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setContentText("Vul een naam in!");
                    alert.showAndWait();
                }
                else {
                    view.getScene().setRoot(viewHomeScreen);
                }
            }
        });
    }

    private void updateView() {

    }



}
