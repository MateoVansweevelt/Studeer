package be.kdg.studeren.view.vragenList;

import be.kdg.studeren.model.VragenList;
import be.kdg.studeren.view.vraagScreen.VraagView;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

public class VragenListPresenter {
    private VragenList model;
    private VragenListView view;

    //private Vraag modelVraag = new Vraag();
    private VraagView viewVraag = new VraagView();

    public VragenListPresenter(VragenList model, VragenListView view) {
        this.model = model;
        this.view = view;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        view.getLvVragenlijst().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
/*                Scene scene = new Scene(viewVraag);
                Stage stage = (Stage) view.getScene().getWindow();
                stage.setScene(scene);*/
                view.getScene().setRoot(viewVraag);
            }
        });


    }

    private void updateView() {

    }

}
