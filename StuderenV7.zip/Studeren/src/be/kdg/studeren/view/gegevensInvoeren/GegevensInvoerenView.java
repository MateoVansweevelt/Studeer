package be.kdg.studeren.view.gegevensInvoeren;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class GegevensInvoerenView extends VBox {

    Label lblGegevensInvoeren;
    Button btnFrans;
    Button btnProgrammeren;

    public GegevensInvoerenView() {
        initializeNodes();
        layoutNodes();
    }

    private void layoutNodes() {
        setPrefSize(400, 400);
        this.setSpacing(10);
        this.getChildren().addAll(lblGegevensInvoeren, btnFrans, btnProgrammeren);
        this.setAlignment(Pos.CENTER);
    }

    private void initializeNodes() {
        lblGegevensInvoeren = new Label("Gegevens Invoeren");
        btnFrans = new Button("Frans");
        btnProgrammeren = new Button("Programmeren");
    }
}
