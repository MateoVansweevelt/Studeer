package be.kdg.studeren.view.titleScreen;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class TitleScreenView extends BorderPane {
    Label lblNaam;
    TextField tfNaam;
    Button btnVerder;

    public TitleScreenView() {
        initialisatieNodes();
        layoutNodes();
    }

    private void initialisatieNodes() {
        lblNaam = new Label("Vul hier uw naam in");
        tfNaam = new TextField();
        btnVerder = new Button("Ga Verder");
    }

    private void layoutNodes() {

        VBox vbox = new VBox(lblNaam,tfNaam,btnVerder);
        BorderPane.setAlignment(btnVerder, Pos.CENTER);
        lblNaam.setPrefWidth(200);
        btnVerder.setPrefWidth(200);
        tfNaam.setPrefWidth(200);

        super.setCenter(vbox);

        vbox.setPrefHeight(500);
        vbox.setPrefWidth(500);
        vbox.setPadding(new Insets(150,50,50,50));
        vbox.setSpacing(50);

    }

    Label getLblNaam() {
        return lblNaam;
    }

    TextField getTfNaam() {
        return tfNaam;
    }

    Button getBtnVerder() {
        return btnVerder;
    }
}
