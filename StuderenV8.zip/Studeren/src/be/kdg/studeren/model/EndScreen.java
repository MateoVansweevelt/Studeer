package be.kdg.studeren.model;

public class EndScreen {
}
