package be.kdg.studeren.model;

import java.util.ArrayList;
import java.util.List;

public class Game {
    private List<Vraag> vragenFrans = new ArrayList<>();
    private List<Vraag> vragenProgrammeren = new ArrayList<>();
    private List<Vraag> vragenStatistiek = new ArrayList<>();

    private String naam;
    private String watIngeven;

    //getters
    public List<Vraag> getVragenFrans() {
        return vragenFrans;
    }
    public List<Vraag> getVragenProgrammeren() {
        return vragenProgrammeren;
    }
    public List<Vraag> getVragenStatistiek() {
        return vragenStatistiek;
    }
    public String getNaam() {
        return naam;
    }

    //setters
    public void setNaam(String naam) {
        this.naam = naam;
    }
    public void setWatIngeven(String watIngeven) {
        this.watIngeven = watIngeven;
    }


}
