package be.kdg.studeren.view.gegevensInvoeren;

import be.kdg.studeren.model.Game;
import be.kdg.studeren.view.vragenList.VragenListPresenter;
import be.kdg.studeren.view.vragenList.VragenListView;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;


public class GegevensInvoerenPresenter {
    private Game model;
    private GegevensInvoerenView view;

    public GegevensInvoerenPresenter(Game model, GegevensInvoerenView view) {
        this.model = model;
        this.view = view;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        view.btnFrans.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                model.setWatIngeven("Frans");
                VragenListView vragenListView = new VragenListView();
                VragenListPresenter vragenListPresenter = new VragenListPresenter(model, vragenListView);
                view.getScene().setRoot(vragenListView);
            }
        });
    }

    private void updateView() {

    }
}
