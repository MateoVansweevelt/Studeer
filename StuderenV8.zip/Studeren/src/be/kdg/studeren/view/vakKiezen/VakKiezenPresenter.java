package be.kdg.studeren.view.vakKiezen;

public class VakKiezenPresenter {
}
