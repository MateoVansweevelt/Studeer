package be.kdg.studeren.view.vragenList;

import be.kdg.studeren.model.Game;
import be.kdg.studeren.model.VragenList;
import be.kdg.studeren.view.gegevensInvoeren.GegevensInvoerenPresenter;
import be.kdg.studeren.view.gegevensInvoeren.GegevensInvoerenView;
import be.kdg.studeren.view.vraagScreen.VraagPresenter;
import be.kdg.studeren.view.vraagScreen.VraagView;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

public class VragenListPresenter {
    private Game model;
    private VragenListView view;

    public VragenListPresenter(Game model, VragenListView view) {
        this.model = model;
        this.view = view;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        view.getLvVragenlijst().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                VraagView viewVraag = new VraagView();
                VraagPresenter vraagPresenter = new VraagPresenter(model, viewVraag);
                view.getScene().setRoot(viewVraag);
            }
        });

        view.getBtnTerug().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                GegevensInvoerenView viewGegevensInvoeren = new GegevensInvoerenView();
                GegevensInvoerenPresenter gegevensInvoerenPresenter = new GegevensInvoerenPresenter(model, viewGegevensInvoeren);
                view.getScene().setRoot(viewGegevensInvoeren);
            }
        });

    }

    private void updateView() {

    }

}
