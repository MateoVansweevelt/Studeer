package be.kdg.studeren.view.titleScreen;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class TitleScreenView extends BorderPane {
    Label lblTitel;
    Label lblNaam;
    TextField tfNaam;
    Button btnVerder;

    public TitleScreenView() {
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {
        lblNaam = new Label("Vul hier uw naam in");
        tfNaam = new TextField();
        btnVerder = new Button("Ga Verder");
        lblTitel = new Label("Studeren");
    }

    private void layoutNodes() {
        this.setTop(lblTitel);
        lblTitel.setId("titel");
        VBox vbox = new VBox(lblNaam, tfNaam, btnVerder);
        vbox.setAlignment(Pos.CENTER);
        tfNaam.setAlignment(Pos.CENTER);
        tfNaam.setPromptText("Naam");
        btnVerder.getParent().requestFocus();
        btnVerder.setPrefWidth(150);
        btnVerder.setPrefHeight(40);
        this.setCenter(vbox);
        vbox.setPadding(new Insets(0, 50, 50, 50));
        vbox.setSpacing(15);
    }

    Label getLblNaam() {
        return lblNaam;
    }

    TextField getTfNaam() {
        return tfNaam;
    }

    Button getBtnVerder() {
        return btnVerder;
    }
}
