package be.kdg.studeren.model;

import java.util.ArrayList;
import java.util.List;

public class Game {
    private List<Vraag> vragenFrans = new ArrayList<>();
    private String naam;
    private String watIngeven;

    public List<Vraag> getVragenFrans() {
        return vragenFrans;
    }

    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }

    public void setWatIngeven(String watIngeven) {
        this.watIngeven = watIngeven;
    }


}
