package be.kdg.studeren.model;

public class VragenListFrans {
}
