package be.kdg.studeren.model;

import java.util.ArrayList;
import java.util.List;

public class VragenListProgrammeren {
    private List<Vraag> vragen;

    public VragenListProgrammeren(){
        vragen = new ArrayList<>();
    }

    public void addVraag(String vraag, String antwoord){
        vragen.add(new Vraag(vraag,antwoord));
    }

    public List<Vraag> getVragen() {
        return vragen;
    }
}
