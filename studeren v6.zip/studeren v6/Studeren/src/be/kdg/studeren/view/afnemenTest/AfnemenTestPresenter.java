package be.kdg.studeren.view.afnemenTest;

import be.kdg.studeren.model.AfnemenTest;

public class AfnemenTestPresenter {
    private AfnemenTest model;
    private AfnemenTestView view;

    public AfnemenTestPresenter(AfnemenTest model, AfnemenTestView view) {
        this.model = model;
        this.view = view;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {

    }

    private void updateView() {

    }
}
