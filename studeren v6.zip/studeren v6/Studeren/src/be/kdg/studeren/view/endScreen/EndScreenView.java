package be.kdg.studeren.view.endScreen;

public class EndScreenView {
}
