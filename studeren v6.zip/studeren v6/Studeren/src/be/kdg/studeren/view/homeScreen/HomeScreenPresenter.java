package be.kdg.studeren.view.homeScreen;

import be.kdg.studeren.model.AfnemenTest;
import be.kdg.studeren.model.Game;
import be.kdg.studeren.model.GegevensInvoeren;
import be.kdg.studeren.model.HomeScreen;
import be.kdg.studeren.view.afnemenTest.AfnemenTestPresenter;
import be.kdg.studeren.view.afnemenTest.AfnemenTestView;
import be.kdg.studeren.view.gegevensInvoeren.GegevensInvoerenPresenter;
import be.kdg.studeren.view.gegevensInvoeren.GegevensInvoerenView;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

public class HomeScreenPresenter {
    private HomeScreen model;
    private HomeScreenView view;

    private AfnemenTest afnemenTest = new AfnemenTest();
    private AfnemenTestView afnemenTestView = new AfnemenTestView();
    private AfnemenTestPresenter afnemenTestPresenter = new AfnemenTestPresenter(afnemenTest, afnemenTestView);

    private GegevensInvoeren gegevensInvoeren = new GegevensInvoeren();
    private GegevensInvoerenView gegevensInvoerenView = new GegevensInvoerenView();
    private GegevensInvoerenPresenter gegevensInvoerenPresenter = new GegevensInvoerenPresenter(gegevensInvoeren, gegevensInvoerenView);

    public HomeScreenPresenter(Game model, HomeScreenView view) {
        this.model = model;
        this.view = view;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        view.getBtnTestAfnemen().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                view.getScene().setRoot(afnemenTestView);
            }
        });
        view.getBtnGegevensInvoeren().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                view.getScene().setRoot(gegevensInvoerenView);
            }
        });
        view.getBtnAfsluiten().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                System.exit(0);
            }
        });
    }

    private void updateView() {

    }
}
