package be.kdg.studeren.view.pauseScreen;

public class PauseScreenPresenter {
}
