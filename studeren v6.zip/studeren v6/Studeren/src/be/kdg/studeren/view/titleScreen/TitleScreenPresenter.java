package be.kdg.studeren.view.titleScreen;

import be.kdg.studeren.model.Game;
import be.kdg.studeren.model.HomeScreen;
import be.kdg.studeren.model.TitleScreen;
import be.kdg.studeren.view.homeScreen.HomeScreenPresenter;
import be.kdg.studeren.view.homeScreen.HomeScreenView;
import be.kdg.studeren.view.vragenList.VragenListView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;

public class TitleScreenPresenter {
    private Game model;
    private TitleScreenView view;

    //private HomeScreen homeScreen = new HomeScreen();
   // private HomeScreenView homeScreenView = new HomeScreenView();
   // private HomeScreenPresenter homeScreenPresenter = new HomeScreenPresenter(homeScreen, homeScreenView);

    public TitleScreenPresenter(Game model, TitleScreenView view) {
        this.model = model;
        this.view = view;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        view.getBtnVerder().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (view.getTfNaam().getText() == null || view.getTfNaam().getText().trim().isEmpty()) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setContentText("Vul een naam in!");
                    alert.showAndWait();
                } else {
                    model.setNaam(view.getTfNaam().getText() );
                    HomeScreenView homeScreenView = new HomeScreenView();
                    HomeScreenPresenter homeScreenPresenter = new HomeScreenPresenter(model, homeScreenView);
                    view.getScene().setRoot(homeScreenView);
                }
            }
        });
    }

    private void updateView() {

    }
}
