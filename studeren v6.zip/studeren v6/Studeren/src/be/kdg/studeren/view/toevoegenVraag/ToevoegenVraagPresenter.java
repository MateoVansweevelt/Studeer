package be.kdg.studeren.view.toevoegenVraag;

public class ToevoegenVraagPresenter {
}
