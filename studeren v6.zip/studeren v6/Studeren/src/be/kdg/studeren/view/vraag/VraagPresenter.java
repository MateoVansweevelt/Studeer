package be.kdg.studeren.view.vraag;

import be.kdg.studeren.model.Vraag;
import be.kdg.studeren.view.vragenList.VragenListView;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

public class VraagPresenter {
    private Vraag model;
    private VraagView view;

    //private VragenListProgrammeren modelVragenList = new VragenListProgrammeren();
    private VragenListView viewVragenList = new VragenListView();

    //TODO
    public VraagPresenter(VraagView view) {
//        this.model = model;
        this.view = view;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        view.getBtnTerug().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                view.getScene().setRoot(viewVragenList);
            }
        });

    }

    private void updateView() {

    }

}
