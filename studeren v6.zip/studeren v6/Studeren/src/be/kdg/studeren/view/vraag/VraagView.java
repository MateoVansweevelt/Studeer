package be.kdg.studeren.view.vraag;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class VraagView extends BorderPane {
    Label lblVraag;
    Label lblAntwoord;
    TextField tfVraag;
    TextField tfAntwoord;
    Button btnSave;
    Button btnTerug;

    public VraagView() {
        initialisatieNodes();
        layoutNodes();
    }

    private void initialisatieNodes() {
        lblVraag = new Label("Vraag: ");
        lblAntwoord = new Label("Antwoord: ");
        tfVraag = new TextField();
        tfAntwoord = new TextField();
        btnSave = new Button("Save");
        btnTerug = new Button("Terug");
    }

    private void layoutNodes() {

        HBox hBoxButtons = new HBox(btnSave,btnTerug);
        VBox vboxVraagView = new VBox(lblVraag,tfVraag,lblAntwoord,tfAntwoord,hBoxButtons);

/*        lblVraag.setPrefWidth(200);
        lblAntwoord.setPrefWidth(200);
        tfVraag.setPrefWidth(200);
        tfAntwoord.setPrefWidth(200);*/

        super.setCenter(vboxVraagView);
        //super.setBottom(hBoxButtons);

        vboxVraagView.setPrefHeight(500);
        vboxVraagView.setPrefWidth(500);
        vboxVraagView.setPadding(new Insets(50,50,50,50));
        vboxVraagView.setSpacing(50);

        hBoxButtons.setPadding(new Insets(25,25,25,25));
        hBoxButtons.setSpacing(150);

    }

    Label getLblVraag() {
        return lblVraag;
    }

    Label getLblAntwoord() {
        return lblAntwoord;
    }

    TextField getTfVraag() {
        return tfVraag;
    }

    TextField getTfAntwoord() {
        return tfAntwoord;
    }

    Button getBtnSave() {
        return btnSave;
    }

    Button getBtnTerug() {
        return btnTerug;
    }
}

