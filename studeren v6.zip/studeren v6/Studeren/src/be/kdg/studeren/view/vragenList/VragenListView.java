package be.kdg.studeren.view.vragenList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class VragenListView extends BorderPane {
    ListView<String> lvVragenlijst;
    Button btnTerug;
    ObservableList<String> lijst;


    public VragenListView() {
        initialisatieNodes();
        layoutNodes();
    }

    private void initialisatieNodes() {
       lijst = FXCollections.<String>observableArrayList("Vraag 1", "Vraag 2", "Vraag 3", "Vraag 4");
        lvVragenlijst = new ListView<>(lijst);
        btnTerug = new Button("Terug");
    }

    private void layoutNodes() {
        VBox vboxVragenlijst = new VBox(lvVragenlijst,btnTerug);
        BorderPane.setAlignment(btnTerug, Pos.CENTER);
        lvVragenlijst.setPrefWidth(250);
        lvVragenlijst.setPrefHeight(500);

        super.setCenter(vboxVragenlijst);

        vboxVragenlijst.setPrefHeight(500);
        vboxVragenlijst.setPrefWidth(500);
        vboxVragenlijst.setPadding(new Insets(50,50,50,50));
        vboxVragenlijst.setSpacing(20);

    }

    ListView getLvVragenlijst() {
        return lvVragenlijst;
    }

    Button getBtnTerug() {
        return btnTerug;
    }

    ObservableList<String> getLijst() {
        return lijst;
    }
}
