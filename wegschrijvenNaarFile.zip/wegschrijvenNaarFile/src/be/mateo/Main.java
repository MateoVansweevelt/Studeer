package be.mateo;

public class Main {
    public static void main(String[] args) {
        InlezenEnWegschrijvenVraagAntwoord i = new InlezenEnWegschrijvenVraagAntwoord();

        i.setAantalVragen();
        i.setVraag();
        i.setAntwoord();
        i.aanmakenBestand();
        i.toevoegenRecords();
        i.sluitbestand();
    }
}
